package com.restAPIJAVA.demo.service.DatabaseManager;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.sql.SQLException;

import java.util.*;

@Service
public class DatabaseManagerService {

    private final DatabaseManagerHelper databaseHelper;

    private final JdbcTemplate jdbcTemplate;

    public DatabaseManagerService(DatabaseManagerHelper databaseHelper, JdbcTemplate jdbcTemplate) {
        this.databaseHelper = databaseHelper;
        this.jdbcTemplate = jdbcTemplate;
    }

    public Map<String, Object> getSchemaStatistics() throws SQLException {
        // String sql = "select foreign_relation from sclpl.schema_master";
        // String sql = "SELECT \"foreign_relation\" FROM \"sclpl\".\"schema_master\"";
        String sql = """
                    SELECT schema_name
                    FROM information_schema.schemata
                    WHERE schema_name NOT IN ('pg_catalog', 'information_schema')
                """;

        List<String> targetSchemas = jdbcTemplate.queryForList(sql, String.class);

        Map<String, Object> response = new LinkedHashMap<>();
        Map<String, Object> schemaDetails = new LinkedHashMap<>();
        int totalTableCount = 0;

        try (var connection = Objects.requireNonNull(jdbcTemplate.getDataSource()).getConnection()) {
            var metaData = connection.getMetaData();

            for (String schema : targetSchemas) {
                if (schema == null)
                    continue;

                List<String> tables = databaseHelper.fetchTablesForSchema(metaData, schema);

                Map<String, Object> details = new HashMap<>();
                details.put("tableCount", tables.size());
                details.put("tables", tables);

                schemaDetails.put(schema, details);
                totalTableCount += tables.size();
            }
        }

        response.put("totalSchemasProcessed", targetSchemas.size());
        response.put("totalTablesAcrossAllSchemas", totalTableCount);
        response.put("schemas", schemaDetails);

        return response;
    }

    public List<String> getAllDataField(String moduleName) {
        String sql = "SELECT data_field_name FROM SCLPL.PL_DM_DATA_FIELD where module_name = ?";
        return jdbcTemplate.queryForList(sql, String.class, moduleName);
    }

    @Transactional
    public Map<String, Object> upsertColumns(Map<String, Object> body) {

        // --- Extract top-level fields (with defaults) ---
        String schema = databaseHelper.isString(body.get("schema"));
        String table = databaseHelper.isString(body.get("table"));

        boolean isUcc = databaseHelper.isBoolean(body.getOrDefault("isUcc", true), true);
        boolean isUserUpdatable = databaseHelper.isBoolean(body.getOrDefault("isUserUpdatable", true), true);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> columns = (List<Map<String, Object>>) body.get("columns");

        databaseHelper.validateInputs(schema, table, columns);
        databaseHelper.validateTableIsUpdatable(schema, table);

        // Prepare response
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("schema", schema);
        resp.put("table", table);
        resp.put("isUcc", isUcc);
        resp.put("isUserUpdatable", isUserUpdatable);

        List<Map<String, Object>> results = new ArrayList<>();

        Set<String> existingCols = databaseHelper.fetchExistingColumns(schema, table);

        for (Map<String, Object> col : columns) {
            Map<String, Object> result = new LinkedHashMap<>();

            String columnName = databaseHelper.isString(col.get("columnName"));
            String displayName = databaseHelper.isString(col.get("columnDisplayName")); // can be null/empty

            String columnTypeRaw = databaseHelper.isString(col.get("columnType"));
            String dataFieldName = databaseHelper.getOptionalString(col.get("columnDataFieldName"), null);

            Integer length = databaseHelper.asInteger(col.get("columnLength"));
            Integer scale = databaseHelper.asInteger(col.get("columnScale"));
            Boolean notNull = databaseHelper.asBoolean(col.getOrDefault("columnNotNull", false));
            String defaultValue = databaseHelper.getOptionalString(col.get("columnDefaultValue"), null);
            boolean isHidden = databaseHelper.isBoolean(col.getOrDefault("columnIsHidden", false), false);

            result.put("columnName", columnName);

            databaseHelper.validateColumnSpec(columnName, columnTypeRaw, dataFieldName);

            // Normalize displayName fallback
            if (displayName == null || displayName.trim().isEmpty()) {
                displayName = columnName;
            }

            DatabaseManagerHelper.TypeResolution tr = databaseHelper.resolveType(columnTypeRaw, dataFieldName, length,
                    scale);

            boolean existsPhysically = existingCols.contains(columnName.toLowerCase(Locale.ROOT));

            System.out.println("existsPhysically : " + existsPhysically);

            try {
                if (!existsPhysically) {
                    // =========================================================
                    // ADD COLUMN (new physical column)
                    // =========================================================
                    String addDdl = databaseHelper.buildAddColumnDDL(
                            schema, table, columnName, tr, notNull, defaultValue);
                    jdbcTemplate.execute(addDdl);

                    existingCols.add(columnName.toLowerCase(Locale.ROOT));

                    // Upsert metadata
                    databaseHelper.upsertColumnInfo(schema, table, columnName,
                            isUcc, isUserUpdatable, tr.sysDatatype, tr.dataFieldName,
                            displayName, isHidden);

                    result.put("action", "ADDED");
                    result.put("message", "Physical column added and metadata saved.");

                } else {

                    // UPDATE EXISTING COLUMN:

                    Boolean prevIsUserUpdatable = databaseHelper.fetchIsUserUpdatable(schema, table, columnName);
                    Boolean prevIsUcc = databaseHelper.fetchIsUcc(schema, table, columnName);

                    boolean wasUserUpdatable = Boolean.TRUE.equals(prevIsUserUpdatable);
                    boolean wasUcc = Boolean.TRUE.equals(prevIsUcc);

                    // --- CASE 1: // Rule: Update the switch to false, but DO NOT apply any other
                    // changes. ---
                    if (wasUserUpdatable && !isUserUpdatable) {
                        databaseHelper.updateIsUserUpdatable(schema, table, columnName, false);

                        result.put("action", "USERUPDATABLE_DISABLED_ONLY");
                        result.put("message", "Column is now locked. Switch set to false; no other changes applied.");
                        results.add(result);
                        continue;
                    }

                    // --- CASE 2: Rule: Block everything. ---
                    if (!wasUserUpdatable && !isUserUpdatable) {
                        result.put("action", "BLOCKED_NOT_USER_UPDATABLE");
                        result.put("message", "Column is not user-updatable. Set switch to true to enable changes.");
                        results.add(result);
                        continue;
                    }

                    // --- CASE 3: Rule: Proceed with full physical and metadata updates. --
                    if (!wasUcc && !isUcc) {
                        result.put("action", "BLOCKED_NOT_UCC");
                        result.put("message", "Only UCC columns can be edited.");
                        results.add(result);
                        continue;
                    }

                    // Proceed with physical / metadata updates
                    String currentPhysicalType = databaseHelper.fetchPhysicalColumnType(schema, table, columnName);
                    boolean typeChangeRequired = currentPhysicalType != null &&
                            databaseHelper.isTypeChangeRequired(currentPhysicalType, tr.physicalSqlType);

                    if (typeChangeRequired) {
                        // Physical Alteration
                        String alterDdl = databaseHelper.buildAlterTypeDDL(schema, table, columnName, tr);
                        jdbcTemplate.execute(alterDdl);

                        // Constraints & Metadata
                        databaseHelper.applyColumnConstraints(schema, table, columnName, notNull, defaultValue);
                        databaseHelper.upsertColumnInfo(schema, table, columnName,
                                isUcc, isUserUpdatable, tr.sysDatatype, tr.dataFieldName,
                                displayName, isHidden);

                        result.put("action", "UPDATED");
                        result.put("message", "Column updated: datatype altered and metadata applied.");
                    } else {
                        // Metadata and Constraints only
                        databaseHelper.applyColumnConstraints(schema, table, columnName, notNull, defaultValue);
                        databaseHelper.upsertColumnInfo(schema, table, columnName,
                                isUcc, isUserUpdatable, tr.sysDatatype, tr.dataFieldName,
                                displayName, isHidden);

                        result.put("action", "METADATA_ONLY");
                        result.put("message", "Column updated: metadata and constraints applied.");
                    }
                }

                result.put("sysDatatype", tr.sysDatatype);
                result.put("physicalSqlType", tr.physicalSqlType);
                result.put("isHidden", isHidden);
                result.put("displayName", displayName);

            } catch (Exception ex) {
                throw new RuntimeException("Failed for column '" + columnName + "': " + ex.getMessage(), ex);
            }

            results.add(result);
        }

        resp.put("results", results);
        return resp;
    }

    public Map<String, Object> getColumnDetails(String moduleName, String tableName, String columnName) {

        // 1) Resolve schema from moduleName
        String schema = moduleName;

        // 2) Validate identifiers (avoid SQL injection in identifiers)
        databaseHelper.validateIdentifier(schema, "schema");
        databaseHelper.validateIdentifier(tableName, "tableName");
        databaseHelper.validateIdentifier(columnName, "columnName");

        // 3) Fetch physical column properties
        Map<String, Object> physical = databaseHelper.fetchPhysicalColumnDetails(schema, tableName, columnName);
        if (physical == null) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Column not found: " + schema + "." + tableName + "." + columnName);
        }

        // 4) Fetch metadata from PL_DM_COLUMN_INFO (may be null if not present)
        Map<String, Object> meta = databaseHelper.fetchColumnInfo(schema, tableName, columnName);

        // 5) Build response
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("moduleName", moduleName);
        resp.put("schema", schema);
        resp.put("tableName", tableName);
        resp.put("columnName", columnName);

        resp.put("dataType", physical.get("dataType"));
        resp.put("length", physical.get("length"));
        resp.put("scale", physical.get("scale"));
        resp.put("defaultValue", physical.get("defaultValue"));
        resp.put("displayName", physical.get("displayName"));

        // default if metadata row not found
        resp.put("isUserUpdatable", meta != null ? meta.get("isUserUpdatable") : Boolean.FALSE);
        resp.put("isHidden", meta != null ? meta.get("isHidden") : Boolean.FALSE);
        resp.put("dataFieldName", meta != null ? meta.get("dataFieldName") : null);

        return resp;
    }

    public String createTable(Map<String, Object> body) {
        return databaseHelper.createTableWithMetadata(body);
    }

    @Transactional
    public Map<String, Object> updateMultipleTableExtensions(Map<String, Object> body) {

        String schema = databaseHelper.asString(body.get("schema"));

        List<Map<String, Object>> tables = (List<Map<String, Object>>) body.get("tables");

        if (schema == null || tables == null || tables.isEmpty()) {
            throw new IllegalArgumentException("Invalid input");
        }

        List<Map<String, Object>> success = new ArrayList<>();
        List<Map<String, Object>> warnings = new ArrayList<>();

        for (Map<String, Object> t : tables) {

            String table = databaseHelper.asString(t.get("table"));
            Integer newExtCountObj = databaseHelper.asInteger(t.get("newExtCount"));
            boolean forceDrop = databaseHelper.asBoolean(t.getOrDefault("forceDrop", false));

            if (table == null || newExtCountObj == null) {
                continue; // skip invalid row safely
            }

            int newExtCount = newExtCountObj;

            databaseHelper.validateUpdateTable(schema, table);

            int currentExtCount = databaseHelper.fetchCurrentExtCount(table, schema);

            if (newExtCount == currentExtCount) {
                success.add(Map.of("table", table, "message", "No change"));
                continue;
            }

            if (newExtCount > currentExtCount) {
                databaseHelper.addTermColumns(schema, table, currentExtCount + 1, newExtCount);

            } else {
                boolean hasData = databaseHelper.checkDataExists(schema, table, newExtCount + 1, currentExtCount);

                if (hasData && !forceDrop) {
                    warnings.add(Map.of(
                            "table", table,
                            "message", "Data exists. Force drop required."));
                    continue;
                }

                databaseHelper.dropTermColumns(schema, table, newExtCount + 1, currentExtCount);
            }

            databaseHelper.updateExtCount(table, newExtCount, schema);

            success.add(Map.of("table", table, "message", "Updated"));
        }

        return Map.of(
                "status", "DONE",
                "success", success,
                "warnings", warnings);
    }

    public Map<String, Object> getTableExtension(Map<String, Object> body) {
        String schemaPrefix = databaseHelper.isString(body.get("schemaPrefix"));

        if (schemaPrefix == null || schemaPrefix.trim().isEmpty()) {
            return Map.of("error", "Schema prefix is required");
        }

        // Map schema prefix to table pattern
        String schemaTablePattern = getSchemaTableName(schemaPrefix);
        if (schemaTablePattern == null) {
            return Map.of("error", "Invalid schema prefix");
        }

        // Dynamic query using information_schema
        String query = """
                SELECT ? as schema_name, table_name, ext_count
                FROM %s
                WHERE table_name IS NOT NULL
                """.formatted(schemaTablePattern);

        List<Map<String, Object>> results = jdbcTemplate.queryForList(query, schemaPrefix);

        return Map.of("data", results, "count", results.size());
    }

    private String getSchemaTableName(String schemaPrefix) {
        return switch (schemaPrefix) {
            case "scldp" -> "scldp.dp_table_ext_config";
            case "sclrp" -> "sclrp.rp_table_ext_config";
            case "scldi" -> "scldi.di_table_ext_config";
            case "scltf" -> "scltf.tf_table_ext_config";
            case "sclbl" -> "sclbl.bl_table_ext_config";
            default -> null;
        };
    }

    public List<String> allColumns(String schema, String tableName) {
        List<String> result = jdbcTemplate.queryForList(
                DatabaserManagerQuery.GET_TABLE_COLUMNS,
                String.class,
                schema,
                tableName);
        System.out.println("result : " + result);
        return result;
    }

    @Transactional
    public Map<String, Object> deleteColumns(Map<String, Object> body) {

        String schema = databaseHelper.asString(body.get("schema"));
        String table = databaseHelper.asString(body.get("table"));

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> columns = (List<Map<String, Object>>) body.get("columns");

        // Optional behavior flags
        boolean deleteMetadata = databaseHelper.isBoolean(body.getOrDefault("deleteMetadata", true), true);
        boolean cascade = databaseHelper.isBoolean(body.getOrDefault("cascade", false), false);

        // Validate schema/table/columns list + identifiers
        databaseHelper.validateDeleteInputs(schema, table, columns);

        // Fetch existing physical cols once
        Set<String> existingCols = databaseHelper.fetchExistingColumns(schema, table);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("schema", schema);
        resp.put("table", table);

        List<Map<String, Object>> results = new ArrayList<>();

        for (Map<String, Object> colObj : columns) {
            Map<String, Object> r = new LinkedHashMap<>();

            String columnName = databaseHelper.asString(colObj.get("columnName"));
            databaseHelper.validateIdentifier(columnName, "columnName");

            r.put("columnName", columnName);

            try {

                databaseHelper.validateTableIsUpdatable(schema, table);
                databaseHelper.validateColumnIsUpdatable(schema, table, columnName);

                boolean existsPhysically = existingCols.contains(columnName.toLowerCase(Locale.ROOT));
                if (!existsPhysically) {

                }

                // 1) UCC Check (ALLOW delete only if true)
                Boolean isUcc = databaseHelper.fetchIsUcc(schema, table, columnName);
                boolean ucc = Boolean.TRUE.equals(isUcc);

                // If missing metadata row OR is_ucc=false => block
                if (!ucc) {
                    r.put("status", "BLOCKED_NOT_UCC");
                    r.put("message", "Only UCC columns can be deleted.");
                    results.add(r);
                    continue;
                }

                // 2) Dependency checks (if present in either table => return instance_names)
                Set<String> wbInstances = databaseHelper.fetchWbInstances(columnName);
                Set<String> ceInstances = databaseHelper.fetchCeInstances(columnName);

                if (!wbInstances.isEmpty() || !ceInstances.isEmpty()) {
                    r.put("status", "BLOCKED_DEPENDENCIES");
                    r.put("message", "Column is referenced in instances. Cannot delete.");

                    if (!wbInstances.isEmpty())
                        r.put("wbInstances", wbInstances);
                    if (!ceInstances.isEmpty())
                        r.put("ceInstances", ceInstances);

                    Set<String> all = new LinkedHashSet<>();
                    all.addAll(wbInstances);
                    all.addAll(ceInstances);
                    r.put("instances", all);

                    results.add(r);
                    continue;
                }

                // 3) Drop from physical table (only if exists)
                if (!existsPhysically) {
                    r.put("status", "NOT_FOUND");
                    r.put("message", "Column not found in table; nothing to drop.");
                    // optional: still delete metadata if requested
                    if (deleteMetadata) {
                        int deleted = databaseHelper.deleteColumnInfo(schema, table, columnName);
                        r.put("metadataDeleted", deleted);
                    }
                    results.add(r);
                    continue;
                }

                // DDL: DROP COLUMN (validated identifiers)
                String ddl = databaseHelper.buildDropColumnDDL(schema, table, columnName, cascade);
                jdbcTemplate.execute(ddl);

                existingCols.remove(columnName.toLowerCase(Locale.ROOT));

                r.put("status", "DELETED");
                r.put("message", "Column deleted from table.");

                // Optional: delete metadata row as well
                if (deleteMetadata) {
                    int deleted = databaseHelper.deleteColumnInfo(schema, table, columnName);
                    r.put("metadataDeleted", deleted);
                }

            } catch (Exception ex) {
                // Partial success mode: collect error and continue
                r.put("status", "ERROR");
                r.put("message", ex.getMessage());
                results.add(r);
                continue;
            }
            results.add(r);
        }

        resp.put("results", results);
        return resp;
    }
}
