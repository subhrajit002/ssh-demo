package com.restAPIJAVA.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restAPIJAVA.demo.service.DatabaseManager.DatabaseManagerService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/database-manager")
public class DatabaseManagerController {

    private final DatabaseManagerService databaseManagerService;

    public DatabaseManagerController(DatabaseManagerService databaseManagerService) {
        this.databaseManagerService = databaseManagerService;
    }

    @GetMapping("/tables")
    public ResponseEntity<Map<String, Object>> getTablesBySchema() {
        try {
            return ResponseEntity.ok(databaseManagerService.getSchemaStatistics());
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                    .body(Map.of("error", "Failed to fetch metadata: " + e.getMessage()));
        }
    }

    @PostMapping("/upsert-columns")
    public Map<String, Object> upsertColumns(@RequestBody Map<String, Object> body) {
        return databaseManagerService.upsertColumns(body);
    }

    @PostMapping("/create-table")
    public String createTable(@RequestBody Map<String, Object> body) {
        return databaseManagerService.createTable(body);
    }

    @PostMapping("/get-table-ext")
    public Map<String, Object> getTableExt(@RequestBody Map<String, Object> body) {
        return databaseManagerService.getTableExtension(body);
    }

    @PostMapping("/update-ext-count")
    public Map<String, Object> updateExtensionCount(@RequestBody Map<String, Object> body) {
        return databaseManagerService.updateMultipleTableExtensions(body);
    }

    @GetMapping("/get-all-tableColumns")
    public List<String> getAllTableColums(@RequestParam String schema, @RequestParam String tableName) {
        return databaseManagerService.allColumns(schema, tableName);
    }

    @GetMapping("/data-fields")
    public List<String> getFieldNamesByModule(@RequestParam String module) {
        return databaseManagerService.getAllDataField(module);
    }

    @GetMapping("/column-details")
    public Map<String, Object> getColumnDetails(
            @RequestParam String moduleName,
            @RequestParam String tableName,
            @RequestParam String columnName) {
        return databaseManagerService.getColumnDetails(moduleName, tableName, columnName);
    }

    @PostMapping("/delete-columns")
    public Map<String, Object> deleteColumns(@RequestBody Map<String, Object> body) {
        return databaseManagerService.deleteColumns(body);
    }

}
