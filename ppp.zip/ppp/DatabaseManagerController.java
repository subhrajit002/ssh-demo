package com.restAPIJAVA.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restAPIJAVA.demo.service.DatabaseManager.DatabaseManagerService;


@RestController
@RequestMapping("/database-manager")
public class DatabaseManagerController {

    private final DatabaseManagerService databaseManagerService;

    public DatabaseManagerController(DatabaseManagerService databaseManagerService) {
        this.databaseManagerService = databaseManagerService;
    }

    @PostMapping("/upsert-columns")
    public Map<String, Object> upsertColumns(@RequestBody Map<String, Object> body) {
        return databaseManagerService.upsertColumns(body);
    }

    @PostMapping("/create-table")
    public String createTable(@RequestBody Map<String, Object> body) {
        return databaseManagerService.createTable(body);
    }

    @PostMapping("/update-ext-count")
    public Map<String, Object> updateExtensionCount(@RequestBody Map<String, Object> body) {
        return databaseManagerService.updateTableExtension(body);
    }

    @GetMapping("/get-all-tableColumns")
    public List<String> getAllTableColums(@RequestParam String schema, @RequestParam String tableName){
        return databaseManagerService.allColumns(schema, tableName);
    }

}
