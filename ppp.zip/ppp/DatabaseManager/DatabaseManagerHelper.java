package com.restAPIJAVA.demo.service.DatabaseManager;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.HashMap;
import java.util.Locale;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Component
public class DatabaseManagerHelper {

    public final JdbcTemplate jdbcTemplate;

    public DatabaseManagerHelper(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // ----- COLUMN HELPER FUNCTION -----

    private static final Pattern IDENT = Pattern.compile("^[a-zA-Z_][a-zA-Z0-9_]*$");

    private static final Map<String, String> ALLOWED_TYPES = Map.ofEntries(
            Map.entry("int", "integer"),
            Map.entry("integer", "integer"),
            Map.entry("bigint", "bigint"),
            Map.entry("boolean", "boolean"),
            Map.entry("date", "date"),
            Map.entry("timestamp", "timestamp"),
            Map.entry("text", "text"),
            Map.entry("varchar", "varchar(255)"),
            Map.entry("decimal", "decimal(18,2)"),
            Map.entry("numeric", "numeric(18,2)"),
            Map.entry("double", "double precision"),
            Map.entry("data_field", "varchar(255)"));

    public String isString(Object o) {
        if (o == null)
            return null;
        String s = String.valueOf(o).trim();
        return s.isEmpty() ? null : s;
    }

    public boolean isBoolean(Object o, boolean defaultVal) {
        if (o == null)
            return defaultVal;
        if (o instanceof Boolean b)
            return b;
        String s = String.valueOf(o).trim().toLowerCase(Locale.ROOT);
        if (s.isEmpty())
            return defaultVal;
        if (s.equals("true") || s.equals("1") || s.equals("yes"))
            return true;
        if (s.equals("false") || s.equals("0") || s.equals("no"))
            return false;
        return defaultVal; // avoid throwing on weird values
    }

    public String getOptionalString(Object o, String def) {
        return (o == null || o.toString().trim().isEmpty()) ? def : o.toString().trim();
    }

    public void validateInputs(String schema, String table, List<Map<String, Object>> columns) {
        if (schema == null || table == null || columns == null || columns.isEmpty()) {
            throw new IllegalArgumentException("Invalid input: schema/table/columns are required.");
        }
        validateIdentifier(schema, "schema");
        validateIdentifier(table, "table");

        // columns must be list of objects
        Set<String> seen = new HashSet<>();
        for (Object c : columns) {
            if (!(c instanceof Map)) {
                throw new IllegalArgumentException("Invalid columns: each entry must be an object.");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> col = (Map<String, Object>) c;

            String name = isString(col.get("columnName"));
            String type = isString(col.get("columnType"));

            if (name == null)
                throw new IllegalArgumentException("columnName is required.");
            validateIdentifier(name, "columnName");

            String key = name.toLowerCase(Locale.ROOT);
            if (!seen.add(key)) {
                throw new IllegalArgumentException("Duplicate columnName in request: " + name);
            }

            if (type == null) {
                throw new IllegalArgumentException("columnType is required for column: " + name);
            }

            // validate type + data_field rule
            String df = isString(col.get("columnDataFieldName"));
            validateColumnSpec(name, type, df);
        }
    }

    public void validateIdentifier(String value, String what) {
        if (value == null || value.isBlank() || !IDENT.matcher(value).matches()) {
            throw new IllegalArgumentException("Invalid " + what + " name: " + value);
        }
    }

    public void validateTableIsUpdatable(String schema, String table) {
        Boolean updatable = jdbcTemplate.queryForObject(
                DatabaserManagerQuery.CHECK_TABLE_UPDATABLE,
                Boolean.class,
                schema, table);

        if (updatable == null || !updatable) {
            throw new IllegalStateException("Table is not updatable: " + schema + "." + table);
        }
    }

    public Set<String> fetchExistingColumns(String schema, String table) {
        List<String> cols = jdbcTemplate.queryForList(
                """
                        SELECT column_name
                        FROM information_schema.columns
                        WHERE table_schema = ? AND table_name = ?
                        """,
                String.class,
                schema, table);
        return cols.stream()
                .filter(Objects::nonNull)
                .map(c -> c.toLowerCase(Locale.ROOT))
                .collect(Collectors.toSet());
    }

    public void validateColumnSpec(String columnName, String columnTypeRaw, String dataFieldName) {
        if (columnName == null || !IDENT.matcher(columnName).matches()) {
            throw new IllegalArgumentException("Invalid columnName: " + columnName);
        }
        if (columnTypeRaw == null || columnTypeRaw.trim().isEmpty()) {
            throw new IllegalArgumentException("columnType missing for column: " + columnName);
        }

        String normalized = normalizeTypeKey(columnTypeRaw);

        if (!ALLOWED_TYPES.containsKey(normalized)) {
            throw new IllegalArgumentException(
                    "columnType not allowed: " + columnTypeRaw + " (column: " + columnName + ")");
        }

        if (normalized.equals("data_field")) {
            if (dataFieldName == null || dataFieldName.trim().isEmpty()) {
                throw new IllegalArgumentException(
                        "columnDataFieldName is required when columnType is Data Field (column: " + columnName + ")");
            }
            // Validate that this data field exists in your system
            // dataFieldLabelToCode(dataFieldName.trim());
        }
    }

    private String normalizeTypeKey(String raw) {
        return raw.trim().toLowerCase(Locale.ROOT);
    }

    public static class TypeResolution {
        public final String sysDatatype; // stored in metadata
        public final String physicalSqlType; // used in ALTER TABLE
        public final String dataFieldName; // metadata only, optional

        public TypeResolution(String sysDatatype, String physicalSqlType, String dataFieldName) {
            this.sysDatatype = sysDatatype;
            this.physicalSqlType = physicalSqlType;
            this.dataFieldName = dataFieldName;
        }
    }

    public TypeResolution resolveType(String type, String dataField, Integer length, Integer scale) {

        if ("Data_Field".equalsIgnoreCase(type)) {
            return new TypeResolution("DATA_FIELD", "VARCHAR(255)", dataField);
        }

        String physical;

        switch (type.toLowerCase()) {
            case "int" -> physical = "INTEGER";
            case "varchar" -> physical = "VARCHAR(" + (length == null ? 255 : length) + ")";
            case "decimal" ->
                physical = "DECIMAL(" + (length == null ? 10 : length) + "," + (scale == null ? 2 : scale) + ")";
            case "boolean" -> physical = "BOOLEAN";
            default -> throw new IllegalArgumentException("Unsupported datatype");
        }

        return new TypeResolution(type.toUpperCase(), physical, null);
    }

    public String buildAddColumnDDL(String schema, String table, String column, TypeResolution tr,
            Boolean notNull, String defaultVal) {

        StringBuilder ddl = new StringBuilder(
                "ALTER TABLE " + schema + "." + table + " ADD COLUMN " + column + " " + tr.physicalSqlType);

        if (Boolean.TRUE.equals(notNull))
            ddl.append(" NOT NULL");
        if (defaultVal != null)
            ddl.append(" DEFAULT '").append(defaultVal).append("'");

        return ddl.toString();
    }

    public void upsertColumnInfo(
            String schema, String table, String column,
            boolean isUcc, boolean isUserUpdatable,
            String sysDatatype, String dataFieldName,
            String displayName, boolean isHidden) {
        // Requires UNIQUE(schema_name, table_name, column_name) for ON CONFLICT
        jdbcTemplate.update(
                """
                        INSERT INTO sclpl.pl_dm_column_info
                        (schema_name, table_name, column_name, is_ucc, is_user_updatable, sys_datatype, data_field_name, display_name, is_hidden)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT (schema_name, table_name, column_name)
                        DO UPDATE SET
                          is_ucc = EXCLUDED.is_ucc,
                          is_user_updatable = EXCLUDED.is_user_updatable,
                          sys_datatype = EXCLUDED.sys_datatype,
                          data_field_name = EXCLUDED.data_field_name,
                          display_name = EXCLUDED.display_name,
                          is_hidden = EXCLUDED.is_hidden
                        """,
                schema, table, column,
                isUcc, isUserUpdatable,
                sysDatatype, dataFieldName,
                displayName, isHidden);
    }

    public String fetchPhysicalColumnType(String schema, String table, String column) {
        return jdbcTemplate.queryForObject(
                """
                        SELECT
                            CASE
                                WHEN data_type = 'character varying'
                                    THEN 'varchar(' || character_maximum_length || ')'
                                WHEN data_type = 'numeric'
                                    THEN 'numeric(' || numeric_precision || ',' || numeric_scale || ')'
                                ELSE data_type
                            END
                        FROM information_schema.columns
                        WHERE table_schema=? AND table_name=? AND column_name=?
                        """,
                String.class,
                schema, table, column);
    }

    public boolean isTypeChangeRequired(String currentType, String requestedPhysicalType) {
        if (currentType == null || requestedPhysicalType == null)
            return false;

        String cur = currentType.replaceAll("\\s+", "").toLowerCase();
        String req = requestedPhysicalType.replaceAll("\\s+", "").toLowerCase();

        return !cur.equals(req);
    }

    public String buildAlterTypeDDL(String schema, String table, String column, TypeResolution tr) {
        return "ALTER TABLE " + schema + "." + table + " ALTER COLUMN " + column + " TYPE " + tr.physicalSqlType;
    }

    public void applyColumnConstraints(String schema, String table, String column,
            Boolean notNull, String defaultVal) {

        if (Boolean.TRUE.equals(notNull))
            jdbcTemplate.execute("ALTER TABLE " + schema + "." + table + " ALTER COLUMN " + column + " SET NOT NULL");

        if (defaultVal != null)
            jdbcTemplate.execute("ALTER TABLE " + schema + "." + table + " ALTER COLUMN " + column + " SET DEFAULT '"
                    + defaultVal + "'");
    }

    // ----- EXTENSION COUNT HELPER FUNCTION -----

    public void updateExtCount(String table, int newExtCount, String configType) {
        String sql = configType.equalsIgnoreCase("DP")
                ? DatabaserManagerQuery.UPDATE_DP_EXT_COUNT
                : DatabaserManagerQuery.UPDATE_RP_EXT_COUNT;

        jdbcTemplate.update(sql, newExtCount, table);
    }

    public void dropTermColumns(String schema, String table, int start, int end) {
        for (int i = end; i >= start; i--) {
            jdbcTemplate.execute(
                    "ALTER TABLE " + schema + "." + table +
                            " DROP COLUMN term" + i);
        }
    }

    public boolean checkDataExists(String schema, String table, int start, int end) {
        StringBuilder sql = new StringBuilder(
                "SELECT COUNT(*) FROM " + schema + "." + table + " WHERE ");

        for (int i = start; i <= end; i++) {
            sql.append("term").append(i).append(" IS NOT NULL");
            if (i < end) {
                sql.append(" OR ");
            }
        }

        Integer count = jdbcTemplate.queryForObject(sql.toString(), Integer.class);
        return count != null && count > 0;
    }

    public void addTermColumns(String schema, String table, int start, int end) {
        for (int i = start; i <= end; i++) {
            jdbcTemplate.execute(
                    "ALTER TABLE " + schema + "." + table
                            + " ADD term" + i + " VARCHAR(255)");
        }
    }

    public int fetchCurrentExtCount(String table, String configType) {
        String sql = configType.equalsIgnoreCase("scldp")
                ? DatabaserManagerQuery.GET_DP_EXT_COUNT
                : DatabaserManagerQuery.GET_RP_EXT_COUNT;

        return jdbcTemplate.queryForObject(sql, Integer.class, table);
    }

    public Map<String, Object> response(
            String status, String message, int oldVal, int newVal) {

        Map<String, Object> map = new HashMap<>();
        map.put("status", status);
        map.put("message", message);
        map.put("oldExtCount", oldVal);
        map.put("newExtCount", newVal);
        return map;
    }

    public Map<String, Object> warningResponse(int start, int end) {
        Map<String, Object> map = new HashMap<>();
        map.put("status", "WARNING");
        map.put("message", "Data exists in term columns term" + start + " to term" + end);
        return map;
    }

    public void validateUpdateTable(String schema, String table) {
        Boolean isUpdateable = jdbcTemplate.queryForObject(
                DatabaserManagerQuery.CHECK_TABLE_UPDATABLE,
                Boolean.class,
                schema,
                table);

        if (isUpdateable == null) {
            throw new IllegalStateException("Table metadata not found");
        }

        if (!isUpdateable) {
            throw new IllegalStateException("Table is not user updatable. ALTER operations are not allowed.");
        }
    }

    public void validateInputs(
            String schema,
            String table,
            List<Map<String, Object>> columns,
            List<String> primaryKeys) {

        if (schema == null || table == null || columns == null || columns.isEmpty()) {
            throw new IllegalArgumentException("Invalid input: schema/table/columns are required.");
        }

        if (!schema.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
            throw new IllegalArgumentException("Invalid schema name: " + schema);
        }
        if (!table.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
            throw new IllegalArgumentException("Invalid table name: " + table);
        }

        Set<String> colNames = new HashSet<>();

        for (Map<String, Object> col : columns) {
            String name = asString(col.get("name"));
            String type = asString(col.get("type"));

            if (name == null || !name.matches("[a-zA-Z_][a-zA-Z0-9_]*")) {
                throw new IllegalArgumentException("Invalid column name: " + name);
            }
            if (type == null || type.trim().isEmpty()) {
                throw new IllegalArgumentException("Datatype missing for column: " + name);
            }

            if (!isAllowedType(type.trim())) {
                throw new IllegalArgumentException("Datatype not allowed: " + type + " (column: " + name + ")");
            }

            if (isDataFieldType(type)) {
                String dfName = asString(col.get("dataFieldName"));
                if (dfName == null || dfName.trim().isEmpty()) {
                    throw new IllegalArgumentException(
                            "dataFieldName is required when type=data_field for column: " + name);
                }
                dataFieldLabelToCode(dfName);
            }

            colNames.add(name);
        }

        if (primaryKeys != null && !primaryKeys.isEmpty()) {
            for (String pk : primaryKeys) {
                if (!colNames.contains(pk)) {
                    throw new IllegalArgumentException(
                            "Primary key '" + pk + "' does not exist in the provided columns list.");
                }
            }
        }
    }

    public String buildCreateTableQuery(
            String schema,
            String table,
            List<Map<String, Object>> columns,
            List<String> primaryKeys) {

        StringBuilder sql = new StringBuilder("CREATE TABLE ")
                .append(schema).append(".").append(table).append(" (");

        for (Map<String, Object> col : columns) {
            String name = asString(col.get("name")).trim();
            String type = asString(col.get("type")).trim();

            boolean notNull = Boolean.TRUE.equals(col.get("notNull"));
            String defaultValue = asString(col.get("defaultValue"));

            String dbType = isDataFieldType(type) ? "integer" : type;

            sql.append(name).append(" ").append(dbType);

            if (notNull) {
                sql.append(" NOT NULL");
            }

            if (defaultValue != null && !defaultValue.trim().isEmpty()) {
                sql.append(" DEFAULT ").append(formatDefault(dbType, defaultValue.trim()));
            }

            sql.append(", ");
        }

        sql.setLength(sql.length() - 2);

        if (primaryKeys != null && !primaryKeys.isEmpty()) {
            sql.append(", PRIMARY KEY (").append(String.join(", ", primaryKeys)).append(")");
        }

        sql.append(")");
        return sql.toString();
    }

    public void safeDropTable(String schema, String table) {
        try {
            String dropSql = "DROP TABLE IF EXISTS " + schema + "." + table;
            jdbcTemplate.execute(dropSql);
            System.out.println("Rolled back by dropping table: " + schema + "." + table);
        } catch (Exception ex) {
            // ignore drop failure to avoid masking original exception
            System.out.println("WARNING: failed to drop table after error: " + ex.getMessage());
        }
    }

    public boolean isDataFieldType(String type) {
        return type != null && type.trim().equalsIgnoreCase("data_field");
    }

    public Integer dataFieldLabelToCode(String label) {
        if (label == null) {
            return null;
        }
        String v = label.trim().toLowerCase();
        return switch (v) {
            case "manual" ->
                1;
            case "coverage" ->
                2;
            default ->
                throw new IllegalArgumentException("Unknown dataFieldName: " + label);
        };
    }

    public boolean tableExists(String schema, String table) {
        String sql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES "
                + "WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, schema, table);
        return count != null && count > 0;
    }

    public boolean isAllowedType(String type) {
        String t = type.trim().toLowerCase();

        if (t.equals("data_field")) {
            return true;
        }

        if (t.equals("int") || t.equals("integer") || t.equals("bigint")
                || t.equals("boolean") || t.equals("date") || t.equals("timestamp") || t.equals("text")) {
            return true;
        }

        if (t.matches("^varchar\\(\\d+\\)$")) {
            return true;
        }

        if (t.matches("^numeric\\(\\d+,\\d+\\)$")) {
            return true;
        }

        return false;
    }

    public String formatDefault(String dbType, String defaultVal) {
        String t = dbType.toLowerCase();

        // allow common expressions without quoting
        if (defaultVal.matches("(?i)^(now\\(\\)|current_timestamp|current_date)$")) {
            return defaultVal;
        }

        // string types -> quote + escape
        if (t.contains("char") || t.contains("varchar") || t.contains("text")) {
            return "'" + defaultVal.replace("'", "''") + "'";
        }

        // numeric/bool -> return raw
        return defaultVal;
    }

    public String asString(Object obj) {
        return (obj == null) ? null : String.valueOf(obj);
    }

    public Integer asInteger(Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof Number) {
            return ((Number) obj).intValue();
        }
        return Integer.valueOf(String.valueOf(obj));
    }

    public boolean asBoolean(Object obj) {
        if (obj instanceof Boolean b) {
            return b;
        }
        if (obj instanceof String s) {
            return Boolean.parseBoolean(s);
        }
        if (obj instanceof Number n) {
            return n.intValue() != 0;
        }
        return false;
    }

}
