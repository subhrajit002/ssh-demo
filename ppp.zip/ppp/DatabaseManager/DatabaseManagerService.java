package com.restAPIJAVA.demo.service.DatabaseManager;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;
import java.util.Locale;

@Service
public class DatabaseManagerService {

    private final DatabaseManagerHelper databaseHelper;

    private final JdbcTemplate jdbcTemplate;

    public DatabaseManagerService(DatabaseManagerHelper databaseHelper, JdbcTemplate jdbcTemplate) {
        this.databaseHelper = databaseHelper;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Transactional
    public Map<String, Object> upsertColumns(Map<String, Object> body) {

        // --- Extract top-level fields (with defaults) ---
        String schema = databaseHelper.isString(body.get("schema"));
        String table = databaseHelper.isString(body.get("table"));

        boolean isUcc = databaseHelper.isBoolean(body.getOrDefault("isUcc", true), true);
        boolean isUserUpdatable = databaseHelper.isBoolean(body.getOrDefault("isUserUpdatable", true), true);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> columns = (List<Map<String, Object>>) body.get("columns");

        databaseHelper.validateInputs(schema, table, columns);
        databaseHelper.validateTableIsUpdatable(schema, table);

        // Prepare response
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("schema", schema);
        resp.put("table", table);
        resp.put("isUcc", isUcc);
        resp.put("isUserUpdatable", isUserUpdatable);

        List<Map<String, Object>> results = new ArrayList<>();

        // Optional: fetch existing columns once (faster)
        Set<String> existingCols = databaseHelper.fetchExistingColumns(schema, table);

        for (Map<String, Object> col : columns) {
            Map<String, Object> result = new LinkedHashMap<>();

            String columnName = databaseHelper.isString(col.get("columnName"));
            String displayName = databaseHelper.isString(col.get("columnDisplayName")); // can be null/empty

            String columnTypeRaw = databaseHelper.isString(col.get("columnType"));
            String dataFieldName = databaseHelper.getOptionalString(col.get("columnDataFieldName"), null);

            Integer length = databaseHelper.asInteger(col.get("columnLength"));
            Integer scale = databaseHelper.asInteger(col.get("columnScale"));
            Boolean notNull = databaseHelper.asBoolean(col.getOrDefault("columnNotNull", false));
            String defaultValue = databaseHelper.getOptionalString(col.get("columnDefaultValue"), null);
            boolean isHidden = databaseHelper.isBoolean(col.getOrDefault("columnIsHidden", false), false);

            result.put("columnName", columnName);

            // Per-column validations
            databaseHelper.validateColumnSpec(columnName, columnTypeRaw, dataFieldName);

            // Normalize displayName fallback
            if (displayName == null || displayName.trim().isEmpty()) {
                displayName = columnName;
            }

            // Resolve into:
            // - sysDatatype (what you store in pl_dm_column_info)
            // - physicalSqlType (what you use for ALTER TABLE)
            DatabaseManagerHelper.TypeResolution tr = databaseHelper.resolveType(columnTypeRaw, dataFieldName, length,
                    scale);

            boolean existsPhysically = existingCols.contains(columnName.toLowerCase(Locale.ROOT));

            try {
                if (!existsPhysically) {
                    // ADD COLUMN
                    String addDdl = databaseHelper.buildAddColumnDDL(schema, table, columnName, tr, notNull,
                            defaultValue);
                    jdbcTemplate.execute(addDdl);

                    existingCols.add(columnName.toLowerCase(Locale.ROOT));

                    // Upsert metadata
                    databaseHelper.upsertColumnInfo(schema, table, columnName,
                            isUcc, isUserUpdatable, tr.sysDatatype, tr.dataFieldName,
                            displayName, isHidden);

                    result.put("action", "ADDED");
                    result.put("message", "Physical column added and metadata saved.");
                } else {
                    // Column exists physically
                    String currentPhysicalType = databaseHelper.fetchPhysicalColumnType(schema, table, columnName);

                    // Corner case: if information_schema returns null (rare), just do metadata
                    boolean typeChangeRequired = currentPhysicalType != null &&
                            databaseHelper.isTypeChangeRequired(currentPhysicalType, tr.physicalSqlType);

                    // If you do NOT want type changes, set this to false always.
                    boolean allowTypeChange = true;

                    if (allowTypeChange && typeChangeRequired) {
                        // ALTER TYPE (may fail if data incompatible)
                        String alterDdl = databaseHelper.buildAlterTypeDDL(schema, table, columnName, tr);
                        jdbcTemplate.execute(alterDdl);

                        databaseHelper.applyColumnConstraints(schema, table, columnName, notNull, defaultValue);

                        databaseHelper.upsertColumnInfo(schema, table, columnName,
                                isUcc, isUserUpdatable, tr.sysDatatype, tr.dataFieldName,
                                displayName, isHidden);

                        result.put("action", "UPDATED");
                        result.put("message", "Column existed: datatype altered and metadata updated.");
                    } else {
                        // Metadata only
                        databaseHelper.applyColumnConstraints(schema, table, columnName, notNull, defaultValue);

                        databaseHelper.upsertColumnInfo(schema, table, columnName,
                                isUcc, isUserUpdatable, tr.sysDatatype, tr.dataFieldName,
                                displayName, isHidden);

                        result.put("action", "METADATA_ONLY");
                        result.put("message", "Column existed: metadata updated.");
                    }
                }

                result.put("sysDatatype", tr.sysDatatype);
                result.put("physicalSqlType", tr.physicalSqlType);
                result.put("isHidden", isHidden);
                result.put("displayName", displayName);

            } catch (Exception ex) {
                // You can choose:
                // 1) fail-fast (rollback everything) -> throw
                // 2) partial success -> collect error and continue
                // Here: fail-fast (better for schema operations)
                throw new RuntimeException("Failed for column '" + columnName + "': " + ex.getMessage(), ex);
            }

            results.add(result);
        }

        resp.put("results", results);
        return resp;
    }

    @Transactional
    public String createTable(Map<String, Object> body) {

        String schema = databaseHelper.asString(body.get("schema"));
        String table = databaseHelper.asString(body.get("table"));

        boolean isUct = databaseHelper.asBoolean(body.getOrDefault("isUct", true));
        boolean isUserUpdatable = databaseHelper.asBoolean(body.getOrDefault("isUserUpdatable", true));
        boolean isDqEnabled = databaseHelper.asBoolean(body.getOrDefault("isDqEnabled", true));

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> columns = (List<Map<String, Object>>) body.get("columns");

        @SuppressWarnings("unchecked")
        List<String> primaryKeys = (List<String>) body.get("primaryKeys");

        databaseHelper.validateInputs(schema, table, columns, primaryKeys);

        if (databaseHelper.tableExists(schema, table)) {
            return "Table already exists";
        }

        String createSql = databaseHelper.buildCreateTableQuery(schema, table, columns, primaryKeys);

        try {
            jdbcTemplate.execute(createSql);

            jdbcTemplate.update(DatabaserManagerQuery.INSERT_TABLE_INFO,
                    schema, table, isUct, isUserUpdatable, isDqEnabled);

            for (Map<String, Object> col : columns) {
                String colName = databaseHelper.asString(col.get("name")).trim();
                String type = databaseHelper.asString(col.get("type")).trim();

                Integer dataFieldCode = null;
                if (databaseHelper.isDataFieldType(type)) {
                    String dfName = databaseHelper.asString(col.get("dataFieldName"));
                    dataFieldCode = databaseHelper.dataFieldLabelToCode(dfName);
                }

                jdbcTemplate.update(DatabaserManagerQuery.INSERT_COLUMN_INFO,
                        schema, table, colName, isUct, isUserUpdatable,
                        type, dataFieldCode, colName, false);
            }

            return "Table created successfully";

        } catch (Exception e) {
            databaseHelper.safeDropTable(schema, table);
            throw e;
        }
    }

    @Transactional
    public Map<String, Object> updateTableExtension(Map<String, Object> body) {

        String schema = databaseHelper.asString(body.get("schema"));
        String table = databaseHelper.asString(body.get("table"));
        int newExtCount = databaseHelper.asInteger(body.get("newExtCount"));
        String moduleName = databaseHelper.asString(body.get("moduleName"));
        boolean forceDrop = databaseHelper.asBoolean(body.getOrDefault("forceDrop", false));

        if (schema == null || table == null || moduleName == null) {
            throw new IllegalArgumentException("Invalid input");
        }
        if (newExtCount < 0) {
            throw new IllegalArgumentException("ext_count cannot be negative");
        }

        databaseHelper.validateUpdateTable(schema, table);

        int currentExtCount = databaseHelper.fetchCurrentExtCount(table, moduleName);

        if (newExtCount == currentExtCount) {
            return databaseHelper.response("SUCCESS", "No change in extension count", currentExtCount, newExtCount);
        }

        if (newExtCount > currentExtCount) {
            databaseHelper.addTermColumns(schema, table, currentExtCount + 1, newExtCount);
        } else {
            boolean hasData = databaseHelper.checkDataExists(schema, table, newExtCount + 1, currentExtCount);

            if (hasData && !forceDrop) {
                return databaseHelper.warningResponse(newExtCount + 1, currentExtCount);
            }

            databaseHelper.dropTermColumns(schema, table, newExtCount + 1, currentExtCount);
        }

        databaseHelper.updateExtCount(table, newExtCount, moduleName);

        return databaseHelper.response("SUCCESS", "Extension updated successfully", currentExtCount, newExtCount);
    }

    public List<String> allColumns(String schema, String tableName) {
        return jdbcTemplate.queryForList(
                DatabaserManagerQuery.GET_TABLE_COLUMNS,
                String.class,
                schema,
                tableName);
    }
}
