package com.restAPIJAVA.demo.service.DatabaseManager;


public class DatabaserManagerQuery {

      public static final String GET_TABLE_INFO = """
                            SELECT schema_name,
                                   table_name,
                                   is_ucct,
                                   is_user_updatable,
                                   is_dq_enabled
                            FROM sclpl.pl_dm_table_info
                            WHERE schema_name = ?
                              AND table_name = ?
                        """;

        public static final String GET_COLUMN_INFO = """
                            SELECT schema_name,
                                   table_name,
                                   column_name,
                                   is_ucc,
                                   is_user_updatable,
                                   syn_datatype,
                                   data_field_name
                            FROM sclpl.pl_dm_column_info
                            WHERE schema_name = ?
                              AND table_name = ?
                            ORDER BY column_name
                        """;

        public static final String INSERT_TABLE_INFO = """
                            INSERT INTO sclpl.pl_dm_table_info
                            (schema_name, table_name, is_uct, , is_dg_enabled)
                            VALUES (?, ?, ?, ?, ?)
                        """;

        public static final String INSERT_COLUMN_INFO = """
                            INSERT INTO sclpl.pl_dm_column_info
                            (schema_name, table_name, column_name, is_ucc, is_user_updatable, sys_datatype, data_field_name, display_name, is_hidden)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """;

        public static final String CHECK_TABLE_EXISTS = """
                            SELECT COUNT(1)
                            FROM sclpl.pl_dm_table_info
                            WHERE schema_name = ?
                              AND table_name = ?
                        """;


        public static final String COUNT_COLUMNS = """
                            SELECT COUNT(1)
                            FROM sclpl.pl_dm_column_info
                            WHERE schema_name = ?
                              AND table_name = ?
                        """;


        public static final String INSERT_DP_EXT_CONFIG = """
                            INSERT INTO sclpl.DP_TABLE_EXT_CONFIG (table_name, ext_count, comment)
                            VALUES (?, ?, ?)
                        """;

        public static final String UPDATE_DP_EXT_CONFIG = """
                            UPDATE sclpl.DP_TABLE_EXT_CONFIG
                            SET ext_count = ?
                            WHERE table_name = ?
                        """;

        public static final String CHECK_TABLE_UPDATABLE = """
                            SELECT is_user_updatable
                            FROM sclpl.pl_dm_table_info
                            WHERE schema_name = ?
                              AND table_name = ?
                        """;

        public static final String GET_DP_EXT_COUNT = """
                            SELECT ext_count
                            FROM scldp.dp_table_ext_config
                            WHERE table_name = ?
                        """;

        public static final String GET_RP_EXT_COUNT = """
                            SELECT ext_count
                            FROM sclrp.RP_TABLE_EXT_CONFIG
                            WHERE table_name = ?
                        """;

        public static final String UPDATE_DP_EXT_COUNT = """
                            UPDATE scldp.dp_table_ext_config
                            SET ext_count = ?
                            WHERE table_name = ?
                        """;

        public static final String UPDATE_RP_EXT_COUNT = """
                            UPDATE sclrp.RP_TABLE_EXT_CONFIG
                            SET ext_count = ?
                            WHERE table_name = ?
                        """;

        public static final String GET_TABLE_COLUMNS = """ 
                            SELECT column_name 
                            FROM information_schema.columns 
                            WHERE table_schema = ? AND table_name = ? 
                            ORDER BY ordinal_position 
                          """;

}
