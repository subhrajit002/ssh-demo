package com.restAPIJAVA.demo.service.DatabaseManager;

public class Query {

}
