import React from 'react'
import './DBMTabButtons.css'

const DBMTabButtons = ({ activeTab, setActiveTab }) => {
  return (
    <div className="dbm-tabs-section mb-4">
      <button
        className={`dbm-tab-btn ${activeTab === "columns" ? "active" : ""}`}
        onClick={() => setActiveTab("columns")}
      >
        User Configured Columns
      </button>
      <button
        className={`dbm-tab-btn ${activeTab === "tables" ? "active" : ""}`}
        onClick={() => setActiveTab("tables")}
      >
        User Configured Tables
      </button>
      <button
        className={`dbm-tab-btn ${activeTab === "nvalued" ? "active" : ""}`}
        onClick={() => setActiveTab("nvalued")}
      >
        N-VALUED TABLES
      </button>
    </div>
  )
}

export default DBMTabButtons