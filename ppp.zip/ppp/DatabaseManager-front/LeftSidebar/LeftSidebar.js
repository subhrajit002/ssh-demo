import { IoIosSearch } from "react-icons/io";
import "./LeftSidebar.css";

const LeftSidebar = ({
    filteredModules,
    toggleModule,
    searchTerm,
    setSearchTerm,
    selectedTable,
    setSelectedTable,
    setSelectedColumn,
    selectedModule,
    setSelectedModule,
}) => {

    const handleToggleModule = (index, module) => {
        toggleModule(index);
        setSelectedModule(module.name);
        setSelectedTable(null);
        setSelectedColumn(null);
    };

    return (
        <div className="dbm-left-sidebar">
            <div className="modules-list">
                {filteredModules.map((module, index) => (
                    <div className="modules_tabs" key={module.name ?? index}>

                        <span
                            className={module.isExpanded ? "expand-icon-true" : "expand-icon"}
                            onClick={() => handleToggleModule(index, module)}
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                                if (e.key === "Enter" || e.key === " ") {
                                    e.preventDefault();
                                    handleToggleModule(index, module);
                                }
                            }}
                            aria-label={module.isExpanded ? "Collapse module" : "Expand module"}
                        >
                            {module.isExpanded ? "▼" : "▶"}
                        </span>

                        <div className="module-section">
                            <div
                                className={`module-header ${module.isExpanded ? "expanded" : ""}`}
                                onClick={() => handleToggleModule(index, module)}
                            >
                                <div className="header-left">
                                    <div className="dbm-color-bar"></div>
                                    <span className="dbm-module-name">{module.name}</span>
                                </div>

                                <span className="dbm-table-count">
                                    <span style={{ fontWeight: "bold", marginRight: "3px" }}>
                                        {module.tableCount}
                                    </span>
                                    Tables
                                </span>
                            </div>

                            {module.isExpanded && (
                                <div className="dbm-search-box-wrapper">
                                    <input
                                        type="text"
                                        placeholder="Enter a keyword to search"
                                        className="dbm-search-input"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    <span className="dbm-search-icon">
                                        <IoIosSearch />
                                    </span>
                                </div>
                            )}

                            {module.isExpanded && (
                                <div className="tables-list">
                                    {module.tables.length > 0 ? (
                                        module.tables.map((table, tableIndex) => (
                                            <div
                                                key={table}
                                                className={`table-item ${selectedTable === table ? "active" : ""}`}
                                                onClick={() => {
                                                    setSelectedTable(table);
                                                    setSelectedColumn(null);
                                                }}
                                            >
                                                <span className="table-name">{table}</span>
                                                {tableIndex === 0 && (
                                                    <span className="table-badge">Real Access Only</span>
                                                )}
                                            </div>
                                        ))
                                    ) : (
                                        <div className="no-results">No tables found</div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default LeftSidebar;