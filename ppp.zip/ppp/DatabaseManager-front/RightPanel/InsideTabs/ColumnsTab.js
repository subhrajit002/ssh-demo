import { MdDeleteOutline } from "react-icons/md";
import { LiaEditSolid } from "react-icons/lia";
import { IoMdAdd } from "react-icons/io";
import "./Alltabs.css";
import { useEffect, useState } from "react";
import ColumnForm from "./ColumnForm";

const ColumnsTab = ({ selectedTable }) => {
    const [activeBtn, setActiveBtn] = useState("");
    const [selectedColumn, setSelectedColumn] = useState(null);

    const [tableColumns, setTableColumns] = useState([
        "product_id",
        "DP_Column1",
        "date",
        "time_bucket",
        "type",
        "DP_Column1",
        "DP_Column1",
        "product_id",
        "DP_Column1",
        "date",
        "time_bucket",
        "type",
        "DP_Column1",
        "DP_Column1"
    ]);

    const handleToggle = (actionName) => {
        // Edit/Delete only when column selected
        if ((actionName === "edit" || actionName === "delete") && !selectedColumn)
            return;

        // Add only when no column selected
        if (actionName === "add" && selectedColumn) return;

        setActiveBtn((prev) => (prev === actionName ? "" : actionName));
    };

    useEffect(() => {
        setActiveBtn("");
        setSelectedColumn(null);
    }, [selectedTable]);

    return (
        <div className="columns-tab">
            <div className="columns-tab-header">
                <p className="col-tab-header-name">{selectedTable}</p>

                <div className="col-tab-actions">
                    <button
                        className={activeBtn === "edit" ? "active" : ""}
                        disabled={selectedColumn === null}
                        onClick={() => handleToggle("edit")}
                        type="button"
                    >
                        <LiaEditSolid className="btn-icon" />
                        Edit
                    </button>

                    <button
                        className={activeBtn === "delete" ? "active" : ""}
                        disabled={selectedColumn === null}
                        onClick={() => handleToggle("delete")}
                        type="button"
                    >
                        <MdDeleteOutline className="btn-icon" />
                        Delete
                    </button>

                    <button
                        className={activeBtn === "add" ? "active" : ""}
                        disabled={selectedColumn !== null}
                        onClick={() => handleToggle("add")}
                        type="button"
                    >
                        <IoMdAdd className="btn-icon" />
                        Add Column
                    </button>
                </div>
            </div>
            <div className="right-columns-body">
                <div className="right-columns-left-body">
                    {tableColumns.map((col, index) => (
                        <div
                            key={index}
                            className={`right-column-item ${selectedColumn === index ? "selected" : ""
                                }`}
                            onClick={() => setSelectedColumn(index)}
                        >
                            {col}
                        </div>
                    ))}
                </div>
                <div className="right-columns-right-body">
                    {activeBtn && (
                        <div className="form-placeholder">
                            {activeBtn === "delete" && <p>Delete Confirmation</p>}
                            {(activeBtn === "edit" || activeBtn === "add") && (
                                <ColumnForm
                                    mode={activeBtn}
                                    selectedColumn={selectedColumn}
                                    onCancel={() => setActiveBtn("")}
                                    selectedTable={selectedTable}
                                />
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ColumnsTab;