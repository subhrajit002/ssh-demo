import { useEffect, useState } from "react";
import "./Alltabs.css";

const emptyColumn = {
    columnName: "",
    displayName: "",
    datatype: "",
    length: "",
    scale: "",
    notNull: false,
    primaryKey: false,
    defaultValue: "",
    isUserUpdatable: false,
    isDGEnabled: false,
};

const ColumnForm = ({
    mode = "add",                 // "add" | "edit"
    selectedColumn = null,
    selectedTable = "U_Table",
    onCancel = () => { },
    onSubmit,                      // optional callback
}) => {
    const [formData, setFormData] = useState(emptyColumn);

    useEffect(() => {
        if (mode === "edit" && selectedColumn) {
            setFormData({
                ...emptyColumn,
                ...selectedColumn,
            });
        } else {
            setFormData(emptyColumn);
        }
    }, [mode, selectedColumn]);

    const handleChange = (field, value) => {
        setFormData((prev) => ({ ...prev, [field]: value }));
    };

    const handleSubmit = () => {
        // You can replace console logs with API call or parent handler
        if (mode === "add") {
            console.log("ADD COLUMN:", formData);
        } else {
            console.log("EDIT COLUMN:", formData);
        }

        if (typeof onSubmit === "function") {
            onSubmit(formData, mode);
        }
    };

    const crumbName =
        mode === "edit"
            ? (formData.columnName || "column_name")
            : "DP_Column";

    return (
        <div className="column-form">
            {/* Header / breadcrumb */}
            <div className="form-header">
                <div className="breadcrumb">
                    <span className="crumb">{selectedTable}</span>
                    <span className="sep">&gt;</span>
                    <span className="crumb active">{crumbName}</span>
                </div>
            </div>

            <div className="form-body">
                {/* Column Name */}
                <div className="field-row">
                    <div className="field-label">Column Name</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <input
                            type="text"
                            placeholder="Enter Column Name"
                            value={formData.columnName}
                            onChange={(e) => handleChange("columnName", e.target.value)}
                        />
                    </div>
                </div>

                {/* Display Name */}
                <div className="field-row">
                    <div className="field-label">Display Name</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <input
                            type="text"
                            placeholder="Enter Display Name"
                            value={formData.displayName}
                            onChange={(e) => handleChange("displayName", e.target.value)}
                        />
                    </div>
                </div>

                {/* Datatype */}
                <div className="field-row">
                    <div className="field-label">Datatype</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <select
                            value={formData.datatype}
                            onChange={(e) => handleChange("datatype", e.target.value)}
                        >
                            <option value="" disabled>
                                Select the Datatype
                            </option>
                            <option value="String">String</option>
                            <option value="Integer">Integer</option>
                            <option value="Date">Date</option>
                            <option value="Decimal">Decimal</option>
                            <option value="Boolean">Boolean</option>
                        </select>
                    </div>
                </div>

                {/* Length */}
                <div className="field-row">
                    <div className="field-label">Length</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <input
                            type="text"
                            placeholder="Enter the length"
                            value={formData.length}
                            onChange={(e) => handleChange("length", e.target.value)}
                        />
                    </div>
                </div>

                {/* Scale */}
                <div className="field-row">
                    <div className="field-label">Scale</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <input
                            type="text"
                            placeholder="Enter the scale"
                            value={formData.scale}
                            onChange={(e) => handleChange("scale", e.target.value)}
                        />
                    </div>
                </div>

                {/* Not Null (Yes/No) */}
                <div className="field-row">
                    <div className="field-label">Not Null</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <div className="yesno">
                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="notNull"
                                    checked={formData.notNull === true}
                                    onChange={() => handleChange("notNull", true)}
                                />
                                <span>Yes</span>
                            </label>

                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="notNull"
                                    checked={formData.notNull === false}
                                    onChange={() => handleChange("notNull", false)}
                                />
                                <span>No</span>
                            </label>
                        </div>
                    </div>
                </div>

                {/* Primary Key (Yes/No) */}
                <div className="field-row">
                    <div className="field-label">PK (Primary Key)</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <div className="yesno">
                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="primaryKey"
                                    checked={formData.primaryKey === true}
                                    onChange={() => handleChange("primaryKey", true)}
                                />
                                <span>Yes</span>
                            </label>

                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="primaryKey"
                                    checked={formData.primaryKey === false}
                                    onChange={() => handleChange("primaryKey", false)}
                                />
                                <span>No</span>
                            </label>
                        </div>
                    </div>
                </div>

                {/* Default Values */}
                <div className="field-row">
                    <div className="field-label">Default Values</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <input
                            type="text"
                            placeholder="Enter the Default Value"
                            value={formData.defaultValue}
                            onChange={(e) => handleChange("defaultValue", e.target.value)}
                        />
                    </div>
                </div>

                {/* Is User Updatable (Yes/No) */}
                <div className="field-row">
                    <div className="field-label">Is User Updatable ?</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <div className="yesno">
                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="isUserUpdatable"
                                    checked={formData.isUserUpdatable === true}
                                    onChange={() => handleChange("isUserUpdatable", true)}
                                />
                                <span>Yes</span>
                            </label>

                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="isUserUpdatable"
                                    checked={formData.isUserUpdatable === false}
                                    onChange={() => handleChange("isUserUpdatable", false)}
                                />
                                <span>No</span>
                            </label>
                        </div>
                    </div>
                </div>

                {/* Is DG Enabled (Yes/No) */}
                <div className="field-row">
                    <div className="field-label">Is DG Enabled ?</div>
                    <div className="field-colon">:</div>
                    <div className="field-control">
                        <div className="yesno">
                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="isDGEnabled"
                                    checked={formData.isDGEnabled === true}
                                    onChange={() => handleChange("isDGEnabled", true)}
                                />
                                <span>Yes</span>
                            </label>

                            <label className="yesno-item">
                                <input
                                    type="radio"
                                    name="isDGEnabled"
                                    checked={formData.isDGEnabled === false}
                                    onChange={() => handleChange("isDGEnabled", false)}
                                />
                                <span>No</span>
                            </label>
                        </div>
                    </div>
                </div>

                {/* Buttons */}
                <div className="form-actions">
                    <button className="btn right-btn-submit" onClick={handleSubmit}>
                        {mode === "add" ? "Submit" : "Update"}
                    </button>
                    <button className="btn right-btn-cancel" onClick={onCancel}>
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    );
}

export default ColumnForm