import React from 'react'

const NValuedTabs = () => {
  return (
    <div>NValuedTabs</div>
  )
}

export default NValuedTabs