import DatabaseManagerHeader from './headers/DatabaseManagerHeader'
import './DatabaseManager.css'
import DBMTabButtons from './DBMTabButtons/DBMTabButtons'
import { useEffect, useState } from 'react';
import LeftSidebar from './LeftSidebar/LeftSidebar';
import RightPanel from './RightPanel/RightPanel';



const DatabaseManager = () => {

  const [activeTab, setActiveTab] = useState("columns");
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddTableForm, setShowAddTableForm] = useState(false);
  const [tableName, setTableName] = useState("");
  const [columns, setColumns] = useState([]);
  const [currentColumn, setCurrentColumn] = useState({
    columnName: "",
    datatype: "String",
    length: "",
    scale: "",
    notNull: false,
    primaryKey: false,
    defaultValue: "",
    isUserUpdatable: false,
    isDGEnabled: false,
  });
  const [successMessage, setSuccessMessage] = useState("");
  const [selectedModule, setSelectedModule] = useState("");
  const [nValuedTableMappings, setNValuedTableMappings] = useState([
    { name: "DP_INTELLICAST", sourceColumns: 104, targetColumns: 100 },
    { name: "DP_HISTORIC_SALES", sourceColumns: 104, targetColumns: 110 },
    { name: "DP_HISTORIC_FORECAST", sourceColumns: 104, targetColumns: 100 },
    { name: "DP_Table1", sourceColumns: 104, targetColumns: 103 },
  ]);

  const [modules, setModules] = useState([
    {
      name: "Demand Planning",
      tableCount: 10,
      isExpanded: false,
      tables: [
        "DP_INTELLICAST",
        "DP_HISTORIC_SALES",
        "DP_HISTORIC_FORECAST",
        "DP_Table1",
        "DP_Table2",
        "DP_Table1",
        "DP_Table1",
        "DP_Table1",
        "DP_Table2",
        "DP_Table1",
      ],
    },
    {
      name: "Replenishment Planning",
      tableCount: 3,
      isExpanded: false,
      tables: ["RP_Table1", "RP_Table2", "RP_Table3"],
    },
    {
      name: "Data Integrator",
      tableCount: 3,
      isExpanded: false,
      tables: ["DI_Table1", "DI_Table2", "DI_Table3"],
    },
    {
      name: "Tradeflow",
      tableCount: 3,
      isExpanded: false,
      tables: ["TF_Table1", "TF_Table2", "TF_Table3"],
    },
    {
      name: "Bussiness Layer",
      tableCount: 3,
      isExpanded: false,
      tables: ["PL_Table1", "PL_Table2", "PL_Table3"],
    },
    {
      name: "Platform Layer",
      tableCount: 3,
      isExpanded: false,
      tables: ["PL_Table1", "PL_Table2", "PL_Table3"],
    },
  ]);

  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedColumn, setSelectedColumn] = useState(null);

  const [tableColumns, setTableColumns] = useState({
    DP_INTELLICAST: ["product_id", "date", "type"],
    DP_HISTORIC_SALES: ["product_id", "date", "time_bucket"],
  });

  const toggleModule = (index) => {
    const newModules = [...modules];
    newModules[index].isExpanded = !newModules[index].isExpanded;
    setModules(newModules);
  };

  const handleAddColumn = () => {
    if (currentColumn.columnName.trim() && tableName.trim()) {
      setColumns([...columns, currentColumn]);
      setCurrentColumn({
        columnName: "",
        datatype: "String",
        length: "",
        scale: "",
        notNull: false,
        primaryKey: false,
        defaultValue: "",
        isUserUpdatable: false,
        isDGEnabled: false,
      });
    }
  };

  const handleSubmit = () => {
    if (tableName.trim() && columns.length > 0) {
      setSuccessMessage("Table created successfully!");
      setTimeout(() => {
        resetForm();
      }, 2000);
    }
  };

  const resetForm = () => {
    setShowAddTableForm(false);
    setTableName("");
    setColumns([]);
    setCurrentColumn({
      columnName: "",
      datatype: "String",
      length: "",
      scale: "",
      notNull: false,
      primaryKey: false,
      defaultValue: "",
      isUserUpdatable: false,
      isDGEnabled: false,
    });
    setSuccessMessage("");
  };

  const handleCancel = () => {
    resetForm();
  };

  const filteredModules = modules.map((module) => ({
    ...module,
    tables: module.tables.filter((table) =>
      table.toLowerCase().includes(searchTerm.toLowerCase()),
    ),
  }));

  useEffect(() => {
    setSelectedTable(null);
    setSelectedColumn(null);
    setSelectedModule("");
    setSuccessMessage("");
    setShowAddTableForm(false);
  }, [activeTab]);



  return (
    <div className='database-Manager'>
      {/* <DatabaseManagerHeader /> */}
      <div className="table-management-container">
        <DBMTabButtons setActiveTab={setActiveTab} activeTab={activeTab} />
        <div className="main-container">
          <LeftSidebar
            filteredModules={filteredModules}
            toggleModule={toggleModule}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            selectedTable={selectedTable}
            setSelectedTable={setSelectedTable}
            setSelectedColumn={setSelectedColumn}
            selectedModule={selectedModule}
            setSelectedModule={setSelectedModule}
          />
          {/* <RightPanel
            toggleModule={toggleModule}
            activeTab={activeTab}
            selectedModule={selectedModule}
            modules={modules}
            nValuedTableMappings={nValuedTableMappings}
            selectedTable={selectedTable}
            selectedColumn={selectedColumn}
            tableColumns={tableColumns}
            setSelectedColumn={setSelectedColumn}
            showAddTableForm={showAddTableForm}
            setShowAddTableForm={setShowAddTableForm}
            successMessage={successMessage}
            tableName={tableName}
            setTableName={setTableName}
            currentColumn={currentColumn}
            setCurrentColumn={setCurrentColumn}
            columns={columns}
            handleAddColumn={handleAddColumn}
            handleSubmit={handleSubmit}
            handleCancel={handleCancel}
          /> */}
          <RightPanel
            activeTab={activeTab}
            selectedModule={selectedModule}
            setSelectedModule={setSelectedModule}   // if needed
            modules={modules}
            toggleModule={toggleModule}            // ✅ ADD THIS
            nValuedTableMappings={nValuedTableMappings}
            selectedTable={selectedTable}
            selectedColumn={selectedColumn}
            tableColumns={tableColumns}
            setSelectedColumn={setSelectedColumn}
            showAddTableForm={showAddTableForm}
            setShowAddTableForm={setShowAddTableForm}
            successMessage={successMessage}
            tableName={tableName}
            setTableName={setTableName}
            currentColumn={currentColumn}
            setCurrentColumn={setCurrentColumn}
            columns={columns}
            handleAddColumn={handleAddColumn}
            handleSubmit={handleSubmit}
            handleCancel={handleCancel}
          />

        </div>
      </div>
    </div>
  )
}

export default DatabaseManager