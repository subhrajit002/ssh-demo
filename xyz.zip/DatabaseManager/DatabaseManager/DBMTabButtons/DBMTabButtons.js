import React from 'react'
import './DBMTabButtons.css'

const DBMTabButtons = ({ activeTab, setActiveTab }) => {
  return (
    <div className="tabs-section mb-4">
      <button
        className={`tab-btn ${activeTab === "columns" ? "active" : ""}`}
        onClick={() => setActiveTab("columns")}
      >
        User Configured Columns
      </button>
      <button
        className={`tab-btn ${activeTab === "tables" ? "active" : ""}`}
        onClick={() => setActiveTab("tables")}
      >
        User Configured Tables
      </button>
      <button
        className={`tab-btn ${activeTab === "nvalued" ? "active" : ""}`}
        onClick={() => setActiveTab("nvalued")}
      >
        N-VALUED TABLES
      </button>
    </div>
  )
}

export default DBMTabButtons