import EmptyStateUI from '../EmptyStateUI/EmptyStateUI';
import ColumnsTab from './InsideTabs/ColumnsTab';
import NValuedTabs from './InsideTabs/NValuedTabs';
import TablesTab from './InsideTabs/TablesTab';
import './RightPanel.css'


const RightPanel = ({
  activeTab,
  selectedModule,
  modules,
  toggleModule,              // ✅ RECEIVE HERE
  nValuedTableMappings,
  selectedTable,
  selectedColumn,
  tableColumns,
  setSelectedColumn,
  showAddTableForm,
  setShowAddTableForm,
  successMessage,
  setCurrentColumn,
  tableName,
  setTableName,
  currentColumn,
  columns,
  handleAddColumn,
  handleSubmit,
  handleCancel
}) => {

  const needsModule = activeTab === "tables";
  const hasSelection = needsModule ? Boolean(selectedModule) : Boolean(selectedTable);

  const emptyText = needsModule ? "Please select a module" : "Please select a table";

  if (!hasSelection) {
    return (
      <div className="right-panel">
        <EmptyStateUI text={emptyText} />
      </div>
    );
  }


  return (
    <div className="right-panel">
      {activeTab === "nvalued" ? (
        <NValuedTabs />
      ) : activeTab === "tables" ? (
        <TablesTab selectedModule={selectedModule} />
      ) : (
        <ColumnsTab toggleModule={toggleModule} selectedTable={selectedTable} selectedModule={selectedModule} />
      )}
    </div>
  );
}

export default RightPanel
