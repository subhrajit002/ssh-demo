import { useEffect, useState } from "react";
import "./Alltabs.css";

const emptyColumn = {
  columnName: "",
  displayName: "",
  datatype: "",
  length: "",
  scale: "",
  notNull: false,
  primaryKey: false,
  defaultValue: "",
  isUserUpdatable: false,
  isDGEnabled: false,
};

const ColumnForm = ({ mode, selectedColumn, onCancel }) => {
  const [formData, setFormData] = useState(emptyColumn);

  // 🔹 Fill data in EDIT mode
  useEffect(() => {
    if (mode === "edit" && selectedColumn) {
      setFormData(selectedColumn);
    } else {
      setFormData(emptyColumn);
    }
  }, [mode, selectedColumn]);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    if (mode === "add") {
      console.log("ADD COLUMN:", formData);
    } else {
      console.log("EDIT COLUMN:", formData);
    }
  };

  return (
    <div className="column-form">
      <h4>{mode === "add" ? "Add Column" : "Edit Column"}</h4>

      <input
        placeholder="Column Name"
        value={formData.columnName}
        onChange={(e) => handleChange("columnName", e.target.value)}
      />

      <input
        placeholder="Display Name"
        value={formData.displayName}
        onChange={(e) => handleChange("displayName", e.target.value)}
      />

      <select
        value={formData.datatype}
        onChange={(e) => handleChange("datatype", e.target.value)}
      >
        <option value="">Select Datatype</option>
        <option>String</option>
        <option>Integer</option>
        <option>Date</option>
      </select>

      <input
        placeholder="Length"
        value={formData.length}
        onChange={(e) => handleChange("length", e.target.value)}
      />

      <input
        placeholder="Scale"
        value={formData.scale}
        onChange={(e) => handleChange("scale", e.target.value)}
      />

      <label>
        <input
          type="checkbox"
          checked={formData.notNull}
          onChange={(e) => handleChange("notNull", e.target.checked)}
        />
        Not Null
      </label>

      <label>
        <input
          type="checkbox"
          checked={formData.primaryKey}
          onChange={(e) => handleChange("primaryKey", e.target.checked)}
        />
        Primary Key
      </label>

      <input
        placeholder="Default Value"
        value={formData.defaultValue}
        onChange={(e) => handleChange("defaultValue", e.target.value)}
      />

      <label>
        <input
          type="checkbox"
          checked={formData.isUserUpdatable}
          onChange={(e) => handleChange("isUserUpdatable", e.target.checked)}
        />
        User Updatable
      </label>

      <label>
        <input
          type="checkbox"
          checked={formData.isDGEnabled}
          onChange={(e) => handleChange("isDGEnabled", e.target.checked)}
        />
        DG Enabled
      </label>

      <div className="form-actions">
        <button onClick={handleSubmit}>
          {mode === "add" ? "Add" : "Update"}
        </button>
        <button onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
};

export default ColumnForm;
