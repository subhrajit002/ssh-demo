import { IoIosSearch } from "react-icons/io";
import './LeftSidebar.css'

const LeftSidebar = ({ filteredModules, toggleModule, searchTerm, setSearchTerm, selectedTable, setSelectedTable, setSelectedColumn, selectedModule, setSelectedModule }) => {

    return (
        <div className="left-sidebar">
            <div className="modules-list">
                {filteredModules.map((module, index) => (
                    <div className="modules_tabs">
                        <span className={`${module.isExpanded ? "expand-icon-true" : "expand-icon"}`}>
                            {module.isExpanded ? "▼" : "▶"}
                        </span>
                        <div key={index} className="module-section">
                            {/* Module Header */}
                            <div
                                className={`module-header ${module.isExpanded ? "expanded" : ""}`}
                                onClick={() => {
                                    toggleModule(index);
                                    setSelectedModule(module.name);
                                    setSelectedTable(null);
                                    setSelectedColumn(null);
                                }}
                            >
                                <div className="header-left">
                                    <div className="color-bar"></div>
                                    <span className="module-name">{module.name}</span>
                                </div>
                                <span className="table-count">
                                    {module.tableCount} Tables
                                </span>
                            </div>

                            {/* Search Box - Only in first expanded module */}
                            {module.isExpanded && (
                                <div className="search-box-wrapper">
                                    <input
                                        type="text"
                                        placeholder="Enter a keyword to search"
                                        className="search-input"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    <span className="search-icon">
                                        <IoIosSearch />
                                    </span>

                                </div>
                            )}

                            {/* Tables List */}
                            {module.isExpanded && (
                                <div className="tables-list">
                                    {module.tables.length > 0 ? (
                                        module.tables.map((table, tableIndex) => (
                                            <div
                                                key={tableIndex}
                                                className={`table-item ${selectedTable === table ? "active" : ""}`}
                                                onClick={() => {
                                                    setSelectedTable(table);
                                                    setSelectedColumn(null);
                                                }}
                                            >
                                                <span className="table-name">{table}</span>
                                                {tableIndex === 0 && (
                                                    <span className="table-badge">
                                                        Real Access Only
                                                    </span>
                                                )}
                                            </div>
                                        ))
                                    ) : (
                                        <div className="no-results">No tables found</div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default LeftSidebar