import './EmptyStateUI.css'

const EmptyStateUI = ({ text = "Please select a module" }) => {
    return (
        <div className="empty-state-wrapper">
            <div className="empty-state-card">
                <h4>{text}</h4>
            </div>
        </div>
    );
};

export default EmptyStateUI