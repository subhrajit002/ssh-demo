import React, { useState } from 'react'

const emptyState = {
  table: "",
  columnName: "",
  type: "INTEGER",
  length: "",
  isPk: false,
  isDqEnabled: true,
  isUserUpdatable: true,
};

const UCTForm = ({ onAddColumn, hasColumns }) => {
  const [form, setForm] = useState(emptyState);

  const handleChange = (key, value) => {
    setForm((p) => ({ ...p, [key]: value }));
  };

  const handleAdd = () => {
    const column = {
      name: form.columnName,
      type: form.type,
      length: form.length ? Number(form.length) : undefined,
      isPk: form.isPk,
    };

    onAddColumn({
      table: form.table,
      isDqEnabled: form.isDqEnabled,
      isUserUpdatable: form.isUserUpdatable,
      column,
    });

    setForm((p) => ({
      ...emptyState,
      table: p.table,
      isDqEnabled: p.isDqEnabled,
      isUserUpdatable: p.isUserUpdatable,
    }));
  };
  return (
    <div className="column-form">

      <div className="form-body">

        {/* Table Name */}
        <div className="field-row">
          <div className="field-label">Table Name</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            {!hasColumns && (
              <input
                type="text"
                placeholder="Table Name"
                value={form.table}
                onChange={(e) => handleChange("table", e.target.value)}
              />
            )}
          </div>
        </div>

        {/* Column Name */}
        <div className="field-row">
          <div className="field-label">Column Name</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="Column Name"
              value={form.columnName}
              onChange={(e) => handleChange("columnName", e.target.value)}
            />
          </div>
        </div>

        {/* Display Name */}
        <div className="field-row">
          <div className="field-label">Display Name</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="Enter Display Name"
            />
          </div>
        </div>

        {/* Datatype + Data Field */}
        <div className="field-row">
          <div className="field-label">Datatype</div>
          <div className="field-colon">:</div>

          <div className="field-control datatype-row">
            <select
              value={form.type}
              onChange={(e) => handleChange("type", e.target.value)}
            >
              <option value="INTEGER">INTEGER</option>
              <option value="VARCHAR">VARCHAR</option>
              <option value="TIMESTAMP">TIMESTAMP</option>
            </select>

            {/* {isDataFieldType && (
              <div className="datafield-wrapper">
                <select
                  value={formData.dataFieldName}
                  disabled={isEdit || loadingDataFields}
                  onChange={(e) => handleChange("dataFieldName", e.target.value)}
                >
                  <option value="" disabled>
                    {loadingDataFields ? "Loading..." : "Select Data Field"}
                  </option>
                  {dataFieldOptions.map((df) => (
                    <option key={df} value={df}>
                      {df}
                    </option>
                  ))}
                </select>

                {dataFieldsError && <div className="inline-error">{dataFieldsError}</div>}
              </div>
            )} */}
          </div>
        </div>

        {/* Length */}
        <div className="field-row">
          <div className="field-label">Length</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="Length"
              value={form.length}
              onChange={(e) => handleChange("length", e.target.value)}
            />
          </div>
        </div>

        {/* Not Null*/}
        <div className="field-row">
          <div className="field-label">Not Null ?</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <div className="yesno">
              <label className="yesno-item">
                <input
                  type="radio"
                  name="isHidden"
                // checked={formData.isHidden === true}
                // onChange={() => handleChange("isHidden", true)}
                />
                <span>Yes</span>
              </label>

              <label className="yesno-item">
                <input
                  type="radio"
                  name="isHidden"
                // checked={formData.isHidden === false}
                // onChange={() => handleChange("isHidden", false)}
                />
                <span>No</span>
              </label>
            </div>
          </div>
        </div>

        {/* PK(Primary Key) */}
        <div className="field-row">
          <div className="field-label">PK(Primary Key) ?</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <div className="yesno">
              <label className="yesno-item">
                <input
                  type="radio"
                  checked={form.isPk}
                  onChange={(e) => handleChange("isPk", e.target.checked)}
                />
                <span>Yes</span>
              </label>

              <label className="yesno-item">
                <input
                  type="radio"
                  checked={form.isPk}
                  onChange={(e) => handleChange("isPk", e.target.checked)}
                />
                <span>No</span>
              </label>
            </div>
          </div>
        </div>



        {/* Default Values */}
        <div className="field-row">
          <div className="field-label">Default Values</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="Enter the Default Value"
            // value={formData.defaultValue ?? ""}
            // disabled={isFieldDisabled("defaultValue")}
            // onChange={(e) => handleChange("defaultValue", e.target.value)}
            />
          </div>
        </div>

        {/* Is DG Enabled */}
        {!hasColumns && (
          <div className="field-row">
            <div className="field-label">Is DG Enabled ?</div>
            <div className="field-colon">:</div>
            <div className="field-control">
              <div className="yesno">
                <label className="yesno-item">
                  <input
                    type="radio"
                    name="isHidden"
                  // checked={formData.isHidden === true}
                  // onChange={() => handleChange("isHidden", true)}
                  />
                  <span>Yes</span>
                </label>

                <label className="yesno-item">
                  <input
                    type="radio"
                    name="isHidden"
                  // checked={formData.isHidden === false}
                  // onChange={() => handleChange("isHidden", false)}
                  />
                  <span>No</span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Is User Updatable */}
        {!hasColumns && (
          <div className="field-row">
            <div className="field-label">Is User Updatable ?</div>
            <div className="field-colon">:</div>
            <div className="field-control">
              <div className="yesno">
                <label className="yesno-item">
                  <input
                    type="radio"
                    name="isHidden"
                  // checked={formData.isHidden === true}
                  // onChange={() => handleChange("isHidden", true)}
                  />
                  <span>Yes</span>
                </label>

                <label className="yesno-item">
                  <input
                    type="radio"
                    name="isHidden"
                  // checked={formData.isHidden === false}
                  // onChange={() => handleChange("isHidden", false)}
                  />
                  <span>No</span>
                </label>
              </div>
            </div>
          </div>
        )}




        {/* Buttons */}
        <div className="form-actions">
          <button
            className="btn right-btn-submit"
            type="button"
          // onClick={handleSubmit}
          // disabled={submitLoading || loadingDetails}
          >
            Add Column
          </button>

          <button
            className="btn right-btn-cancel"
            type="button"
          // onClick={onCancel}
          // disabled={submitLoading || loadingDetails}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}

export default UCTForm