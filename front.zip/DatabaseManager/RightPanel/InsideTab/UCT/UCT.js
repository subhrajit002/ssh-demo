import { FaPlus } from "react-icons/fa6";
import "./UCT.css";
import { useState } from "react";
import UCTForm from "./UCTForm";
import UCTResult from "./UCTResult";

const UCT = () => {
  const [showTab, setShowTab] = useState(false);
  const [columns, setColumns] = useState([]);
  const [tableMeta, setTableMeta] = useState(null);
  const [created, setCreated] = useState(false);

  const handleAddColumn = (data) => {
    if (!tableMeta) {
      setTableMeta({
        table: data.table,
        isDqEnabled: data.isDqEnabled,
        isUserUpdatable: data.isUserUpdatable,
      });
    }

    setColumns((prev) => [...prev, data.column]);
  };

  const handleCreateTable = () => {
    const payload = {
      schema: "sclpl",
      table: tableMeta?.table,
      isUct: true,
      isUserUpdatable: tableMeta?.isUserUpdatable,
      isDqEnabled: tableMeta?.isDqEnabled,
      columns,
      primaryKeys: columns
        .filter((c) => c.isPk)
        .map((c) => c.name),
    };

    console.log("FINAL PAYLOAD →", payload);

    // TODO: call backend

    setCreated(true);
  };

  if (created) {
    return (
      <div className="right-panel-success">
        Table Created Successfully !
      </div>
    );
  }

  return (
    <div className="UTC-tab">
      {!showTab && (
        <div className="UTC-tab-header">
          <button onClick={() => setShowTab(true)}>
            <FaPlus /> Add Table
          </button>
        </div>
      )}

      {showTab && (
        <div className="UTC-tab-body">
          <div className="UTC-tab-left-body">
            <UCTForm onAddColumn={handleAddColumn} hasColumns={columns.length > 0} />
          </div>

          <div className="UTC-tab-right-body">
            <UCTResult
              columns={columns}
              onCreateTable={handleCreateTable}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default UCT;