import React, { useState } from "react";

const UCTResult = ({ columns, onCreateTable }) => {
  if (!columns.length) {
    return (
      <div className="dbm-right-empty">
        <p>Add a column to begin.</p>
      </div>
    );
  }

  return (
    <div className="UTC-right-body-content">
      {columns.map((c, i) => (
        <div key={i} className="UTC-right-column-item">
          {c.name} ({c.type}) {c.isPk && "[PK]"}
        </div>
      ))}

      <button onClick={onCreateTable}>Create Table</button>
    </div>
  );
};

export default UCTResult;
