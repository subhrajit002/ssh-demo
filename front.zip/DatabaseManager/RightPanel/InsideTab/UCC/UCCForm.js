import { useEffect, useMemo, useState } from "react";
import "./UCC.css";
import axios from "axios";

const emptyColumn = {
  columnName: "",
  displayName: "",
  datatype: "",
  length: "",
  scale: "",
  defaultValue: "",
  isUserUpdatable: false,
  isHidden: false,
  dataFieldName: "",
};

const MAX_IDENTIFIER_LEN = 63;

const sanitizeColumnName = (value) => {
  if (!value) return "";
  let v = String(value).trim();
  v = v.replace(/\s+/g, "_");
  v = v.replace(/[^a-zA-Z0-9_]/g, "_");
  v = v.replace(/_+/g, "_");
  if (/^\d/.test(v)) v = "_" + v;
  if (v.length > MAX_IDENTIFIER_LEN) v = v.slice(0, MAX_IDENTIFIER_LEN);
  return v;
};

const TYPE_RULES = {
  int: { length: false, scale: false },
  integer: { length: false, scale: false },

  "Double Precision": { length: false, scale: false },
  "double precision": { length: false, scale: false },

  boolean: { length: false, scale: false },
  date: { length: false, scale: false },
  timestamp: { length: false, scale: false },

  "Character Varying": { length: true, scale: false, maxLength: 255 },
  varchar: { length: true, scale: false, maxLength: 255 },

  DATA_FIELD: { length: false, scale: false },
};

const normType = (t) => (t || "").trim();
const onlyDigits = (v) => String(v || "").replace(/[^\d]/g, "");

const UCCForm = ({
  mode = "add",
  selectedColumn = null,
  selectedColumnName = "",
  selectedTable = "U_Table",
  selectedSchemaKey = "",
  onCancel = () => { },
  onSubmit,
}) => {
  const [formData, setFormData] = useState(emptyColumn);

  const [dataFieldOptions, setDataFieldOptions] = useState([]);
  const [loadingDataFields, setLoadingDataFields] = useState(false);
  const [dataFieldsError, setDataFieldsError] = useState("");

  const [submitLoading, setSubmitLoading] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [submitSuccess, setSubmitSuccess] = useState("");

  const [loadingDetails, setLoadingDetails] = useState(false);

  const isEdit = mode === "edit";

  const isDataFieldType = useMemo(() => {
    const dt = (formData.datatype || "").toLowerCase().trim();
    return dt === "data field" || dt === "data_field" || dt === "datafield" || dt === "data_field";
  }, [formData.datatype]);

  // Existing logic: for add + data field -> disable length/scale/default
  const disableForDataFieldInAdd = !isEdit && isDataFieldType;

  const editableInEditMode = useMemo(
    () => new Set(["displayName", "length", "scale", "defaultValue", "isUserUpdatable"]),
    []
  );

  const normalizeUpdatableMessage = (msg) => {
    const s = String(msg || "");
    const lower = s.toLowerCase();
    if (lower.includes("table is not updatable")) return "Table is not updatable";
    if (lower.includes("column is not updatable")) return "Column is not updatable";
    if (lower.includes("not updatable")) return "Check if the table / column is updatable or not";
    if (lower.includes("incorrect result size")) return "Check if the table / column is updatable or not";
    return s || "Something went wrong.";
  };

  const getFriendlyErrorMessage = (err) => {
    const status = err?.response?.status;
    const msg =
      err?.response?.data?.message ||
      err?.response?.data?.error ||
      err?.message ||
      "";

    const lower = String(msg).toLowerCase();

    if (status === 500 || lower.includes("not updatable") || lower.includes("incorrect result size")) {
      return "Check if the table / column is updatable or not";
    }

    return String(msg) || "Something went wrong.";
  };

  const currentRules = useMemo(() => {
    const key = normType(formData.datatype);
    return TYPE_RULES[key] || { length: false, scale: false };
  }, [formData.datatype]);

  // Existing disable rules + datatype rules
  const isFieldDisabled = (field) => {
    if (field === "isHidden") return false;

    // Data Field add-mode restriction
    if (!isEdit && disableForDataFieldInAdd) {
      if (field === "length" || field === "scale" || field === "defaultValue") return true;
    }

    // Datatype restrictions
    if (field === "length" && !currentRules.length) return true;
    if (field === "scale" && !currentRules.scale) return true;

    // Edit mode restrictions
    if (isEdit) return !editableInEditMode.has(field);

    return false;
  };

  const mapApiDataTypeToSelectValue = (apiDataType) => {
    if (!apiDataType) return "";
    const t = String(apiDataType).toLowerCase();

    if (t.includes("character varying") || t.includes("varchar")) return "Character Varying";
    if (t === "integer" || t.includes("int")) return "int";
    if (t.includes("double precision") || t.includes("float")) return "Double Precision";
    if (t.includes("timestamp")) return "timestamp";
    if (t === "date") return "date";
    if (t === "boolean") return "boolean";

    return apiDataType;
  };

  const fetchColumnDetails = async () => {
    const url = `${process.env.REACT_APP_API_URL}/database-manager/column-details`;

    setLoadingDetails(true);
    setSubmitError("");
    setSubmitSuccess("");
    setDataFieldsError("");

    try {
      const res = await axios.get(url, {
        params: {
          moduleName: selectedSchemaKey,
          tableName: selectedTable,
          columnName: selectedColumnName,
        },
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      });

      const d = res.data || {};
      const hasDataFieldName = d.dataFieldName && String(d.dataFieldName).trim().length > 0;

      const next = {
        ...emptyColumn,
        columnName: d.columnName || selectedColumnName || "",
        displayName: d.displayName || d.columnDisplayName || "",
        datatype: hasDataFieldName ? "DATA_FIELD" : mapApiDataTypeToSelectValue(d.dataType),
        length: d.length ?? "",
        scale: d.scale ?? "",
        defaultValue: d.defaultValue ?? "",
        isUserUpdatable: Boolean(d.isUserUpdatable),
        isHidden: Boolean(d.isHidden),
        dataFieldName: hasDataFieldName ? d.dataFieldName : "",
      };

      setFormData(next);
    } catch (err) {
      console.error("Column details API error:", err);
      const apiMsg =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        "Failed to load column details.";
      setSubmitError(normalizeUpdatableMessage(apiMsg));
    } finally {
      setLoadingDetails(false);
    }
  };

  useEffect(() => {
    setSubmitError("");
    setSubmitSuccess("");
    setDataFieldsError("");

    if (!isEdit) {
      setFormData(emptyColumn);
      return;
    }

    if (isEdit && selectedSchemaKey && selectedTable && selectedColumnName) {
      fetchColumnDetails();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, selectedSchemaKey, selectedTable, selectedColumnName]);

  const handleChange = (field, value) => {
    setSubmitError("");
    setSubmitSuccess("");

    setFormData((prev) => {
      const next = { ...prev, [field]: value };

      if (field === "datatype") {
        const dt = normType(value);
        const lower = dt.toLowerCase();

        const nowDataField =
          lower === "data field" || lower === "data_field" || lower === "datafield";

        const rules = TYPE_RULES[dt] || { length: false, scale: false };

        // If switching away from datafield -> clear datafield name
        if (!nowDataField) {
          next.dataFieldName = "";
          setDataFieldsError("");
        }

        // Clear unsupported fields based on datatype rules
        if (!rules.length) next.length = "";
        if (!rules.scale) next.scale = "";

        // For data_field in add mode, clear fields
        if (!isEdit && nowDataField) {
          next.length = "";
          next.scale = "";
          next.defaultValue = "";
        }

        // If Character Varying and length empty -> default 255
        if ((dt === "Character Varying" || dt === "varchar") && (!next.length || String(next.length).trim() === "")) {
          next.length = "255";
        }
      }

      return next;
    });
  };

  const fetchDataFields = async () => {
    const url = `${process.env.REACT_APP_API_URL}/database-manager/data-fields`;

    setLoadingDataFields(true);
    setDataFieldsError("");

    try {
      const res = await axios.get(url, {
        params: { module: selectedSchemaKey.slice(-2).toUpperCase() },
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      });

      const list = Array.isArray(res.data) ? res.data : res.data?.data || [];
      const normalized = list
        .map((x) => (typeof x === "string" ? x : x?.name || x?.label || x?.dataFieldName))
        .filter(Boolean);

      setDataFieldOptions(normalized);
    } catch (err) {
      console.error("Data field API error:", err);
      setDataFieldsError(err?.response?.data?.message || err?.message || "Failed to load data fields.");
      setDataFieldOptions([]);
    } finally {
      setLoadingDataFields(false);
    }
  };

  useEffect(() => {
    if (isDataFieldType && selectedSchemaKey && selectedTable) fetchDataFields();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDataFieldType, selectedSchemaKey, selectedTable]);

  const buildBackendPayload = () => {
    const toIntOrNull = (v) => {
      if (v === null || v === undefined) return null;
      const s = String(v).trim();
      if (s === "") return null;
      const n = Number(s);
      return Number.isFinite(n) ? n : null;
    };

    return {
      schema: selectedSchemaKey,
      table: selectedTable,
      isUcc: true,
      isUserUpdatable: Boolean(formData.isUserUpdatable),
      columns: [
        {
          columnName: formData.columnName,
          columnDisplayName: formData.displayName,
          columnType: formData.datatype,
          columnDataFieldName: isDataFieldType ? formData.dataFieldName : null,

          columnLength: disableForDataFieldInAdd ? null : toIntOrNull(formData.length),
          columnScale: disableForDataFieldInAdd ? null : toIntOrNull(formData.scale),
          columnDefaultValue: disableForDataFieldInAdd
            ? null
            : formData.defaultValue
              ? String(formData.defaultValue)
              : null,

          columnNotNull: false,
          columnIsHidden: Boolean(formData.isHidden),
        },
      ],
    };
  };

  const callUpsertApi = async (payload) => {
    const url = `${process.env.REACT_APP_API_URL}/database-manager/upsert-columns`;
    return axios.post(url, payload, {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });
  };

  const validateLengthScale = () => {
    const dt = normType(formData.datatype);
    const rules = TYPE_RULES[dt] || { length: false, scale: false };

    const toInt = (v) => {
      const n = Number(String(v || "").trim());
      return Number.isFinite(n) ? n : null;
    };

    if (rules.length) {
      const len = toInt(formData.length);
      if (len === null) return "Length is required for this datatype.";
      if (len <= 0) return "Length must be a positive number.";

      if (rules.maxLength && len > rules.maxLength) return `Length cannot exceed ${rules.maxLength}.`;
    }

    if (rules.scale) {
      const sc = toInt(formData.scale);
      if (sc === null) return "Scale is required for this datatype.";
      if (sc < 0) return "Scale cannot be negative.";

      const len = toInt(formData.length);
      if (len !== null && sc > len) return "Scale cannot be greater than Length (precision).";
    }

    return "";
  };

  const handleSubmit = async () => {
    setSubmitError("");
    setSubmitSuccess("");
    setDataFieldsError("");

    if (!selectedSchemaKey || !selectedTable) {
      setSubmitError("Schema/Table missing. Please select a table.");
      return;
    }

    if (!formData.columnName || !formData.columnName.trim()) {
      setSubmitError("Column Name is required.");
      return;
    }

    // sanitize once more before submit (safety)
    const cleanedName = sanitizeColumnName(formData.columnName);
    if (cleanedName !== formData.columnName) {
      setFormData((p) => ({ ...p, columnName: cleanedName }));
    }

    if (!formData.datatype || !String(formData.datatype).trim()) {
      setSubmitError("Datatype is required.");
      return;
    }

    if (isDataFieldType && (!formData.dataFieldName || !formData.dataFieldName.trim())) {
      setDataFieldsError("Please select a Data Field name.");
      return;
    }

    const lenScaleErr = validateLengthScale();
    if (lenScaleErr) {
      setSubmitError(lenScaleErr);
      return;
    }

    const payload = buildBackendPayload();

    try {
      setSubmitLoading(true);
      const res = await callUpsertApi(payload);

      const apiResp = res?.data || {};
      const r0 = apiResp?.results?.[0] || {};
      const status = String(r0?.status || "").toUpperCase();

      if (status === "ERROR" || status.startsWith("BLOCKED")) {
        const cleaned = normalizeUpdatableMessage(r0?.message || "Failed to save column.");
        setSubmitError(cleaned);
        setSubmitSuccess("");

        if (typeof onSubmit === "function") await onSubmit(apiResp, mode);
        return;
      }

      const msg = r0?.message || (isEdit ? "Column updated successfully." : "Column added successfully.");
      setSubmitSuccess(msg);

      if (typeof onSubmit === "function") await onSubmit(apiResp, mode);
    } catch (err) {
      console.error("Upsert API Error:", err);

      const friendly = normalizeUpdatableMessage(getFriendlyErrorMessage(err));
      setSubmitError(friendly);
      setSubmitSuccess("");

      if (typeof onSubmit === "function") {
        await onSubmit({ results: [{ status: "ERROR", message: friendly }] }, mode);
      }
    } finally {
      setSubmitLoading(false);
    }
  };

  const crumbName = isEdit ? selectedColumnName || formData.columnName || "column" : "";

  return (
    <div className="column-form">
      <div className="form-header">
        <div className="breadcrumb">
          <span className="crumb">{selectedTable}</span>
          <span className="sep">&gt;</span>
          <span className="crumb active">{crumbName}</span>
        </div>

        <div className="form-header-status">
          {submitError && <span className="header-error">{normalizeUpdatableMessage(submitError)}</span>}
          {submitSuccess && <span className="header-success">{submitSuccess}</span>}
        </div>
      </div>

      <div className="form-body">
        {loadingDetails && isEdit && <div className="loader">Loading column details...</div>}

        {/* Column Name */}
        <div className="field-row">
          <div className="field-label">Column Name</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="Enter Column Name"
              value={formData.columnName}
              disabled={isFieldDisabled("columnName")}
              onChange={(e) => handleChange("columnName", sanitizeColumnName(e.target.value))}
            />
          </div>
        </div>

        {/* Display Name */}
        <div className="field-row">
          <div className="field-label">Display Name</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="Enter Display Name"
              value={formData.displayName}
              disabled={isFieldDisabled("displayName")}
              onChange={(e) => handleChange("displayName", e.target.value)}
            />
          </div>
        </div>

        {/* Datatype + Data Field */}
        <div className="field-row">
          <div className="field-label">Datatype</div>
          <div className="field-colon">:</div>

          <div className="field-control datatype-row">
            <select
              className="right-body-dropdown"
              value={formData.datatype}
              disabled={isFieldDisabled("datatype")}
              onChange={(e) => handleChange("datatype", e.target.value)}
            >
              <option value="" disabled>
                Select the Datatype
              </option>
              <option value="int">Integer</option>
              <option value="Character Varying">Character Varying</option>
              <option value="Double Precision">Double Precision</option>
              <option value="date">Date</option>
              <option value="timestamp">Timestamp</option>
              <option value="boolean">Boolean</option>
              <option value="DATA_FIELD">Data Field</option>
            </select>

            {isDataFieldType && (
              <div className="datafield-wrapper">
                <select
                  value={formData.dataFieldName}
                  disabled={isEdit || loadingDataFields}
                  onChange={(e) => handleChange("dataFieldName", e.target.value)}
                >
                  <option value="" disabled>
                    {loadingDataFields ? "Loading..." : "Select Data Field"}
                  </option>
                  {dataFieldOptions.map((df) => (
                    <option key={df} value={df}>
                      {df}
                    </option>
                  ))}
                </select>

                {dataFieldsError && <div className="inline-error">{dataFieldsError}</div>}
              </div>
            )}
          </div>
        </div>

        {/* Length */}
        <div className="field-row">
          <div className="field-label">Length</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder={currentRules.length ? `Max ${currentRules.maxLength || ""}` : "N/A"}
              value={formData.length ?? ""}
              disabled={isFieldDisabled("length")}
              onChange={(e) => {
                const digits = onlyDigits(e.target.value);
                // clamp if maxLength exists
                if (currentRules.maxLength) {
                  const n = Number(digits || 0);
                  if (Number.isFinite(n) && n > currentRules.maxLength) {
                    handleChange("length", String(currentRules.maxLength));
                    return;
                  }
                }
                handleChange("length", digits);
              }}
            />
          </div>
        </div>

        {/* Scale */}
        <div className="field-row">
          <div className="field-label">Scale</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="N/A"
              value={formData.scale ?? ""}
              disabled={isFieldDisabled("scale")}
              onChange={(e) => handleChange("scale", onlyDigits(e.target.value))}
            />
          </div>
        </div>

        {/* Default Values */}
        <div className="field-row">
          <div className="field-label">Default Values</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <input
              type="text"
              placeholder="Enter the Default Value"
              value={formData.defaultValue ?? ""}
              disabled={isFieldDisabled("defaultValue")}
              onChange={(e) => handleChange("defaultValue", e.target.value)}
            />
          </div>
        </div>

        {/* Is Hidden */}
        <div className="field-row">
          <div className="field-label">Is Hidden ?</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <div className="yesno">
              <label className="yesno-item">
                <input
                  type="radio"
                  name="isHidden"
                  checked={formData.isHidden === true}
                  onChange={() => handleChange("isHidden", true)}
                />
                <span>Yes</span>
              </label>

              <label className="yesno-item">
                <input
                  type="radio"
                  name="isHidden"
                  checked={formData.isHidden === false}
                  onChange={() => handleChange("isHidden", false)}
                />
                <span>No</span>
              </label>
            </div>
          </div>
        </div>

        {/* Is User Updatable */}
        <div className="field-row">
          <div className="field-label">Is User Updatable ?</div>
          <div className="field-colon">:</div>
          <div className="field-control">
            <div className="yesno">
              <label className={`yesno-item ${isFieldDisabled("isUserUpdatable") ? "disabled" : ""}`}>
                <input
                  type="radio"
                  name="isUserUpdatable"
                  checked={formData.isUserUpdatable === true}
                  disabled={isFieldDisabled("isUserUpdatable")}
                  onChange={() => handleChange("isUserUpdatable", true)}
                />
                <span>Yes</span>
              </label>

              <label className={`yesno-item ${isFieldDisabled("isUserUpdatable") ? "disabled" : ""}`}>
                <input
                  type="radio"
                  name="isUserUpdatable"
                  checked={formData.isUserUpdatable === false}
                  disabled={isFieldDisabled("isUserUpdatable")}
                  onChange={() => handleChange("isUserUpdatable", false)}
                />
                <span>No</span>
              </label>
            </div>
          </div>
        </div>

        {/* Buttons */}
        <div className="form-actions">
          <button
            className="btn right-btn-submit"
            onClick={handleSubmit}
            type="button"
            disabled={submitLoading || loadingDetails}
          >
            {submitLoading ? (isEdit ? "Updating..." : "Submitting...") : isEdit ? "Update" : "Submit"}
          </button>

          <button
            className="btn right-btn-cancel"
            onClick={onCancel}
            type="button"
            disabled={submitLoading || loadingDetails}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};


export default UCCForm