import "./UCC.css";

const DeleteColumnsModal = ({ isOpen, onClose, dependencyRows = [] }) => {
    if (!isOpen) return null;

    const onOverlayClick = (e) => {
        if (e.target.classList.contains("dbm-modal-overlay")) onClose();
    };

    return (
        <div className="dbm-modal-overlay" onMouseDown={onOverlayClick}>
            <div className="dbm-modal">
                <div className="dbm-modal-top">
                    <button className="dbm-modal-close" onClick={onClose} type="button">
                        ✕ Cancel
                    </button>
                </div>

                <div className="dbm-modal-body">
                    <div className="dbm-modal-title">
                        Check and de-link all the related connections before implementing the procedure
                    </div>

                    <div className="dbm-dependency-list">
                        {dependencyRows.length > 0 ? (
                            dependencyRows.map((row, idx) => (
                                <div className="dbm-dependency-row" key={`${row.columnName}-${row.instanceName}-${idx}`}>
                                    <span className="dbm-dep-col">{row.columnName}</span>
                                    <span className="dbm-dep-arrow">→</span>
                                    <span className="dbm-dep-inst">{row.instanceName}</span>
                                </div>
                            ))
                        ) : (
                            <div className="dbm-no-deps">No linked instances found.</div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DeleteColumnsModal;