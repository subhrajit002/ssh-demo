import "./UCC.css";
import { useEffect, useMemo, useState } from "react";
import DeleteColumnsModal from "./DeleteColumnsModal";
import axios from "axios";
// import edit_icon from "../../../../../../CommonAssests/Images/edit_icon.png";
// import delete_icon from "../../../../../../CommonAssests/Icons/delete_icon.png";
import { FaPlus } from "react-icons/fa6";
import UCCForm from "./UCCForm";

const UCC = ({ selectedTable, selectedSchemaKey }) => {
  const [activeBtn, setActiveBtn] = useState("");
  const [loadingColumns, setLoadingColumns] = useState(false);
  const [tableColumns, setTableColumns] = useState([]);
  const [columnError, setColumnError] = useState("");
  const [selectedColumnNames, setSelectedColumnNames] = useState(new Set());

  const [deleting, setDeleting] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [dependencyRows, setDependencyRows] = useState([]);
  const [deleteApiRawResponse, setDeleteApiRawResponse] = useState(null);

  const [rightStatus, setRightStatus] = useState(null);

  const getColName = (col) => (typeof col === "string" ? col : col?.columnName);

  const selectedCount = selectedColumnNames.size;
  const selectedColumnsArray = useMemo(() => Array.from(selectedColumnNames), [selectedColumnNames]);

  const singleSelectedName = useMemo(() => {
    if (selectedCount === 1) return Array.from(selectedColumnNames)[0];
    return null;
  }, [selectedCount, selectedColumnNames]);

  const singleSelectedColumnObj = useMemo(() => {
    if (!singleSelectedName) return null;
    return tableColumns.find((c) => getColName(c) === singleSelectedName) || null;
  }, [tableColumns, singleSelectedName]);

  // Button rules
  const disableEdit = selectedCount !== 1;
  const disableDelete = selectedCount === 0;
  const disableAdd = selectedCount !== 0;

  const normalizeUpdatableMessage = (msg) => {
    const s = String(msg || "");
    const lower = s.toLowerCase();

    if (lower.includes("table is not updatable")) return "Table is not updatable";
    if (lower.includes("column is not updatable")) return "Column is not updatable";
    if (lower.includes("not updatable")) return "Check if the table / column is updatable or not";

    // common JDBC error when queryForObject returns 0 rows
    if (lower.includes("incorrect result size")) return "Check if the table / column is updatable or not";

    return s || "Something went wrong.";
  };

  const getFriendlyErrorMessage = (err) => {
    const status = err?.response?.status;
    const backendMsg =
      err?.response?.data?.message ||
      err?.response?.data?.error ||
      err?.message ||
      "";

    const msg = String(backendMsg);
    const lower = msg.toLowerCase();

    // If 500 OR known updatable related messages
    if (
      status === 500 ||
      lower.includes("not updatable") ||
      lower.includes("incorrect result size")
    ) {
      return "Check if the table / column is updatable or not";
    }

    return msg || "Something went wrong.";
  };

  const toggleSelectColumn = (colName) => {
    setRightStatus(null);
    setSelectedColumnNames((prev) => {
      const next = new Set(prev);
      if (next.has(colName)) next.delete(colName);
      else next.add(colName);
      return next;
    });
  };

  const clearSelection = () => setSelectedColumnNames(new Set());

  const getAllColumnsOfTable = async () => {
    const url = `${process.env.REACT_APP_API_URL}/database-manager/get-all-tableColumns`;
    setLoadingColumns(true);
    setColumnError("");

    try {
      const res = await axios.get(url, {
        params: { schema: selectedSchemaKey, tableName: selectedTable },
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      });

      setTableColumns(res.data || []);
    } catch (err) {
      console.error("API Error:", err);
      setColumnError(
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        "Failed to load columns."
      );
      setTableColumns([]);
    } finally {
      setLoadingColumns(false);
    }
  };

  useEffect(() => {
    if (selectedTable && selectedSchemaKey) getAllColumnsOfTable();

    setActiveBtn("");
    clearSelection();
    setShowDeleteModal(false);
    setDependencyRows([]);
    setDeleteApiRawResponse(null);
    setRightStatus(null);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTable, selectedSchemaKey]);

  useEffect(() => {
    if (activeBtn === "edit" && disableEdit) setActiveBtn("");
    if (activeBtn === "add" && disableAdd) setActiveBtn("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCount]);

  const handleClickEdit = () => {
    if (disableEdit) return;
    setRightStatus(null);
    setActiveBtn((prev) => (prev === "edit" ? "" : "edit"));
  };

  const handleClickAdd = () => {
    if (disableAdd) return;
    setRightStatus(null);
    setActiveBtn((prev) => (prev === "add" ? "" : "add"));
  };

  const extractDependencyRows = (apiResp) => {
    const rows = [];
    const results = apiResp?.results || [];

    results.forEach((r) => {
      const col = r.columnName;
      const merged =
        r.instances ||
        [
          ...(Array.isArray(r.wbInstances) ? r.wbInstances : []),
          ...(Array.isArray(r.ceInstances) ? r.ceInstances : []),
        ];

      if (Array.isArray(merged) && merged.length > 0) {
        merged.forEach((inst) => rows.push({ columnName: col, instanceName: inst }));
      }
    });

    return rows;
  };

  const handleClickDelete = async () => {
    if (disableDelete || deleting) return;

    setActiveBtn("");
    setRightStatus(null);
    setShowDeleteModal(false);
    setDependencyRows([]);
    setDeleteApiRawResponse(null);

    const payload = {
      schema: selectedSchemaKey,
      table: selectedTable,
      columns: selectedColumnsArray.map((c) => ({ columnName: c })),
      deleteMetadata: true,
      cascade: false,
    };

    try {
      setDeleting(true);

      const url = `${process.env.REACT_APP_API_URL}/database-manager/delete-columns`;
      const res = await axios.post(url, payload, {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      });

      const apiResp = res.data || {};
      setDeleteApiRawResponse(apiResp);

      const deps = extractDependencyRows(apiResp);

      if (deps.length > 0) {
        setDependencyRows(deps);
        setShowDeleteModal(true);
        setRightStatus({
          type: "info",
          text: "Deletion blocked due to linked instances. Please de-link and retry.",
        });
        return;
      }

      const results = apiResp?.results || [];
      const deleted = results.filter((r) => r.status === "DELETED").map((r) => r.columnName);
      const blocked = results.filter((r) => String(r.status || "").startsWith("BLOCKED"));
      const errors = results.filter((r) => r.status === "ERROR");

      if (deleted.length > 0) {
        setRightStatus({
          type: "success",
          text: deleted.length === 1 ? "Column deleted" : `Columns deleted: ${deleted.join(", ")}`,
        });
        clearSelection();
        await getAllColumnsOfTable();
      } else if (blocked.length > 0) {
        setRightStatus({
          type: "error",
          text: normalizeUpdatableMessage(blocked[0]?.message || "Some columns are blocked."),
        });
      } else if (errors.length > 0) {
        setRightStatus({
          type: "error",
          text: normalizeUpdatableMessage(errors[0]?.message || "Delete failed."),
        });
      } else {
        setRightStatus({
          type: "info",
          text: "No columns deleted.",
        });
      }
    } catch (err) {
      console.error("Delete API Error:", err);
      setRightStatus({
        type: "error",
        text: normalizeUpdatableMessage(getFriendlyErrorMessage(err)),
      });
    } finally {
      setDeleting(false);
    }
  };

  const safeUpper = (s) => (s ? String(s).toUpperCase() : "");

  return (
    <div className="columns-tab">
      <div className="columns-tab-header">
        <p className="col-tab-header-name">
          {selectedTable ? safeUpper(selectedTable) : "SELECT A TABLE"}
        </p>

        <div className="col-tab-actions">
          <button
            className={`action-btn ${activeBtn === "edit" ? "active" : ""}`}
            disabled={disableEdit}
            onClick={handleClickEdit}
            type="button"
            title={disableEdit ? "Select exactly one column to edit" : "Edit selected column"}
          >
            <img
              height="18px"
              width="auto"
              // src={edit_icon}
              style={{ marginRight: "8px", opacity: disableEdit ? 0.4 : 1 }}
              alt="edit_icon"
            />
            Edit
          </button>

          <button
            className={`action-btn ${showDeleteModal ? "active" : ""}`}
            disabled={disableDelete || deleting}
            onClick={handleClickDelete}
            type="button"
            title={disableDelete ? "Select one or more columns to delete" : "Delete selected columns"}
          >
            <img
              height="18px"
              width="auto"
              // src={delete_icon}
              style={{ marginRight: "8px", opacity: disableDelete ? 0.4 : 1 }}
              alt="delete"
            />
            {deleting ? "Deleting..." : "Delete"}
          </button>

          <button
            className={`action-btn ${activeBtn === "add" ? "active" : ""}`}
            disabled={disableAdd}
            onClick={handleClickAdd}
            type="button"
            title={disableAdd ? "Deselect columns to add a new column" : "Add a new column"}
            style={{ width: "130px" }}
          >
            <FaPlus style={{ marginRight: "8px" }} />
            Add Column
          </button>
        </div>
      </div>

      <div className="right-columns-body">
        {columnError && <p className="error-text">{columnError}</p>}

        {loadingColumns ? (
          <div className="loader">Loading Columns...</div>
        ) : (
          <>
            <div className="right-columns-left-body">
              {tableColumns.length > 0 ? (
                tableColumns.map((col, index) => {
                  const colName = getColName(col);
                  const selected = selectedColumnNames.has(colName);

                  return (
                    <div
                      key={`${colName}-${index}`}
                      className={`right-column-item ${selected ? "selected" : ""}`}
                      onClick={() => toggleSelectColumn(colName)}
                      title="Click to select/deselect. Multiple selection allowed."
                    >
                      <p>{colName}</p>
                    </div>
                  );
                })
              ) : (
                <p>No columns found.</p>
              )}
            </div>

            <div className="right-columns-right-body">
              {activeBtn && (
                <div className="form-placeholder">
                  {(activeBtn === "edit" || activeBtn === "add") && (
                    <UCCForm
                      mode={activeBtn}
                      selectedColumn={singleSelectedColumnObj}
                      selectedColumnName={singleSelectedName}
                      selectedTable={selectedTable}
                      selectedSchemaKey={selectedSchemaKey}
                      onCancel={() => {
                        setActiveBtn("");
                        setRightStatus(null);
                      }}
                      onSubmit={async (apiResp) => {
                        const r0 = apiResp?.results?.[0];
                        const status = String(r0?.status || "").toUpperCase();

                        if (status === "ERROR" || status.startsWith("BLOCKED")) {
                          setRightStatus({
                            type: "error",
                            text: normalizeUpdatableMessage(r0?.message || "Operation failed."),
                          });
                          return;
                        }

                        setRightStatus({
                          type: "success",
                          text: r0?.message || "Column saved successfully.",
                        });

                        setActiveBtn("");
                        clearSelection();
                        await getAllColumnsOfTable();
                      }}
                    />
                  )}
                </div>
              )}

              {!activeBtn && !rightStatus && (
                <div className="dbm-right-empty">
                  {!selectedTable ? (
                    <>
                      <h4>No table selected</h4>
                      <p>Please select a table from the left panel to view or manage columns.</p>
                    </>
                  ) : (
                    <>
                      <h4>No action selected</h4>
                      <p>
                        Select a column to <b>Edit</b> / <b>Delete</b>, or click <b>Add Column</b> to create a new one.
                      </p>
                    </>
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </div>

      <DeleteColumnsModal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        dependencyRows={dependencyRows}
      />
    </div>
  );
};


export default UCC