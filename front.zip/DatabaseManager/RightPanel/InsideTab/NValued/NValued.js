import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './Nvalued.css';

const NValued = ({ selectedSchemaKey, selectedModule }) => {
    const [tables, setTables] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [selectedTables, setSelectedTables] = useState([]);
    const [newCounts, setNewCounts] = useState({});
    const [touched, setTouched] = useState({});
    const [warningTables, setWarningTables] = useState([]);
    const [showForceModal, setShowForceModal] = useState(false);
    const [modalMessage, setModalMessage] = useState("");




    const getTableName = (col) => (typeof col === "string" ? col : col?.columnName);

    const handleNewCountChange = (tableName, value) => {
        // allow empty
        if (value === "") {
            setNewCounts(prev => ({ ...prev, [tableName]: "" }));
            return;
        }

        // only digits allowed
        if (!/^\d+$/.test(value)) return;

        const num = Number(value);

        // allow storing value even if >200 (for tooltip display)
        setNewCounts(prev => ({ ...prev, [tableName]: num }));
    };

    const getError = (value) => {
        if (value === "" || value === undefined) return "Value required";
        if (value < 1) return "Must be greater than 0";
        if (value > 200) return "Cannot exceed 200";
        return "";
    };


    const isRebuildDisabled =
        selectedTables.length === 0 ||
        selectedTables.some(table => {
            const name = getTableName(table?.table_name);
            return getError(newCounts[name]);
        });


    const toggleTableSelection = (table) => {
        const tableName = getTableName(table?.table_name);
        if (selectedTables.some(t => getTableName(t?.table_name) === tableName)) {
            // remove if already selected
            setSelectedTables(selectedTables.filter(t => getTableName(t?.table_name) !== tableName));
        } else {
            // add if not selected
            setSelectedTables([...selectedTables, table]);
        }
    };

    const fetchTableExtensions = async (schemaKey) => {
        if (!schemaKey) return;
        setLoading(true);
        setError("");
        try {
            const response = await axios.post(
                'http://localhost:8080/database-manager/get-table-ext',
                { schemaPrefix: schemaKey }
            );

            // assuming API returns array of tables
            setTables(response.data.data || []);
        } catch (err) {
            console.error('Error fetching table extensions:', err);
            setError("Failed to load N-Valued tables");
            setTables([]);
        } finally {
            setLoading(false);
        }
    };

    const callUpdateAPI = async (tablesPayload) => {
        try {
            const res = await axios.post(
                "http://localhost:8080/database-manager/update-ext-count",
                {
                    schema: selectedSchemaKey,
                    tables: tablesPayload
                }
            );

            const data = res.data;

            // SUCCESS → refresh table list
            if (data.success?.length) {
                await fetchTableExtensions(selectedSchemaKey);
                setSelectedTables([]);
                setNewCounts({});
            }

            // WARNING → open modal
            if (data.warnings?.length) {
                setWarningTables(data.warnings);
                setModalMessage("Some tables contain data. Force drop required.");
                setShowForceModal(true);
            }

        } catch (err) {
            console.error("Update failed", err);
        }
    };


    const handleRebuild = async () => {
        const payload = selectedTables.map(table => {
            const tableName = getTableName(table?.table_name);

            return {
                table: tableName,
                newExtCount: Number(newCounts[tableName]),
                forceDrop: false
            };
        });

        await callUpdateAPI(payload);
    };

    const handleForceSubmit = async () => {
        const payload = warningTables.map(t => ({
            table: t.table,
            newExtCount: Number(newCounts[t.table]),
            forceDrop: true
        }));

        // close modal first
        setShowForceModal(false);

        // call API again with forceDrop = true
        await callUpdateAPI(payload);
    };



    useEffect(() => {
        fetchTableExtensions(selectedSchemaKey);
    }, [selectedSchemaKey]);

    const safeUpper = (s) => (s ? String(s).toUpperCase() : "");

    return (
        <div className="columns-tab">
            <div className="columns-tab-header">
                <p className="col-tab-header-name">
                    {selectedModule ? safeUpper(selectedModule) : "SELECT A TABLE"}
                </p>

                <div className="col-tab-actions">
                    <button
                        className="action-btn"
                        type="button"
                        disabled={isRebuildDisabled}
                        onClick={handleRebuild}
                    >
                        Re-Build Table
                    </button>
                </div>
            </div>

            {/* Body */}
            <div className="right-columns-body">
                {!loading && error && (
                    <div className="no-results" style={{ color: "red" }}><span>Failed to load tables</span></div>
                )}

                {loading ? (
                    <div className="loader">Loading Tables...</div>
                ) : (
                    <>
                        <div className="right-columns-left-body">
                            {tables.length > 0 ? (
                                tables.map((table, index) => {
                                    const tableName = getTableName(table?.table_name);
                                    return (
                                        <div
                                            key={`${tableName}-${index}`}
                                            className={`right-column-item ${selectedTables.some(t => getTableName(t?.table_name) === tableName) ? "selected" : ""}`}
                                            onClick={() => toggleTableSelection(table)}
                                            style={{ display: "flex", justifyContent: "space-between", cursor: "pointer" }}
                                        >
                                            <span>{tableName ?? "Unknown Table"}</span>
                                            <span>{table?.ext_count ?? "—"} Columns</span>
                                        </div>
                                    );
                                })
                            ) : (
                                <p>No Tables found.</p>
                            )}
                        </div>

                        <div className="right-columns-right-body">
                            {selectedTables.length > 0 ? (
                                selectedTables.map((table, index) => {
                                    const tableName = getTableName(table?.table_name);

                                    return (
                                        <div key={`${tableName}-selected-${index}`} className="nvalued-compare-row">

                                            {/* Table name */}
                                            <span className="compare-table-name">{tableName}</span>

                                            {/* Old column count */}
                                            <input
                                                className="compare-count old"
                                                value={table?.ext_count ?? ""}
                                                disabled
                                            />

                                            {/* Arrow */}
                                            <span className="compare-arrow">→</span>

                                            <div className="compare-input-wrapper">
                                                <input
                                                    className={`compare-count new ${getError(newCounts[tableName]) ? "error" : ""
                                                        }`}
                                                    value={newCounts[tableName] ?? ""}
                                                    onChange={(e) => handleNewCountChange(tableName, e.target.value)}
                                                    onBlur={() =>
                                                        setTouched(prev => ({ ...prev, [tableName]: true }))
                                                    }
                                                    inputMode="numeric"
                                                    maxLength={3}
                                                />

                                                {touched[tableName] && getError(newCounts[tableName]) && (
                                                    <div className="tooltip-error">
                                                        {getError(newCounts[tableName])}
                                                    </div>
                                                )}
                                            </div>



                                            {/* Columns label */}
                                            <span className="compare-label">Columns</span>

                                        </div>
                                    );
                                })
                            ) : (
                                <div className="dbm-right-empty">
                                    <p>No tables selected.</p>
                                </div>
                            )}
                        </div>

                    </>
                )}
            </div>

            {showForceModal && (
                <div className="modal-overlay">
                    <div className="modal-box">
                        <h3>Force Drop Required</h3>
                        <p>{modalMessage}</p>

                        <ul>
                            {warningTables.map((t, i) => (
                                <li key={i}>{t.table}</li>
                            ))}
                        </ul>

                        <div className="modal-actions">
                            <button onClick={() => setShowForceModal(false)}>Cancel</button>
                            <button onClick={handleForceSubmit}>Submit</button>
                        </div>
                    </div>
                </div>
            )}


        </div>
    );
};

export default NValued;
