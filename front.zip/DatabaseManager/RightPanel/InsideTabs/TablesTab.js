import React from 'react'

const TablesTab = () => {
  return (
    <div>TablesTab</div>
  )
}

export default TablesTab