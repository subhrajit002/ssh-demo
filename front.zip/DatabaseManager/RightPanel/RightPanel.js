import EmptyStateUI from '../EmptyStateUI/EmptyStateUI';
import './RightPanel.css'
import UCC from './InsideTab/UCC/UCC';
import UCT from './InsideTab/UCT/UCT';
import NValued from './InsideTab/NValued/NValued';


const RightPanel = ({
  activeTab,
  selectedModule,
  toggleModule,
  selectedTable,
  selectedSchemaKey,
}) => {

  const needsModule = activeTab === "tables" || activeTab === "nvalued";
  const hasSelection = needsModule ? Boolean(selectedModule) : Boolean(selectedTable);


  const emptyText = needsModule ? "Please select a module" : "Please select a table";

  if (!hasSelection) {
    return (
      <div className="right-panel">
        <EmptyStateUI text={emptyText} />
      </div>
    );
  }


  return (
    <div className="right-panel">
      {activeTab === "nvalued" ? (
        <NValued selectedSchemaKey={selectedSchemaKey} selectedModule={selectedModule} />
      ) : activeTab === "tables" ? (
        <UCT selectedModule={selectedModule} />
      ) : (
        <UCC toggleModule={toggleModule} selectedTable={selectedTable} selectedSchemaKey={selectedSchemaKey} />
      )}
    </div>
  );
}

export default RightPanel
