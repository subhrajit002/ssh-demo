import { IoIosSearch } from "react-icons/io";
import "./LeftSidebar.css";

const LeftSidebar = ({
    filteredModules,
    toggleModule,
    searchTerm,
    setSearchTerm,
    selectedTable,
    setSelectedTable,
    setSelectedColumn,
    selectedModule,
    setSelectedModule,
    loadingTables,
    tablesError,
    setSelectedSchemaKey,
    activeTab
}) => {

    const handleToggleModule = (index, module) => {
        toggleModule(index);
        setSelectedModule(module.name);
        setSelectedTable(null);
        setSelectedColumn(null);
        setSelectedSchemaKey(module.schemaKey);
    };

    return (
        <div className="dbm-left-sidebar">
            <div className="modules-list">

                {!loadingTables && tablesError && (
                    <div className="no-results" style={{ color: "red" }}>
                        {tablesError}
                    </div>
                )}

                {!loadingTables && !tablesError && filteredModules.length === 0 && (
                    <div className="no-results">No modules found</div>
                )}

                {!loadingTables && !tablesError && filteredModules.map((module, index) => (
                    <div className="modules_tabs" key={module.name ?? index}>

                        {activeTab !== "nvalued" && (
                            <span
                                className={module.isExpanded ? "expand-icon-true" : "expand-icon"}
                                onClick={() => handleToggleModule(index, module)}
                                role="button"
                                tabIndex={0}
                                onKeyDown={(e) => {
                                    if (e.key === "Enter" || e.key === " ") {
                                        e.preventDefault();
                                        handleToggleModule(index, module);
                                    }
                                }}
                                aria-label={module.isExpanded ? "Collapse module" : "Expand module"}
                            >
                                {module.isExpanded ? "▼" : "▶"}
                            </span>
                        )}

                        <div className="module-section">
                            <div
                                className={`module-header ${module.isExpanded ? "expanded" : ""}`}
                                onClick={() => handleToggleModule(index, module)}
                            >
                                <div className="header-left">
                                    <div className="dbm-color-bar"></div>
                                    <span className="dbm-module-name">{module.name}</span>
                                </div>

                                <span className="dbm-table-count">
                                    <span style={{ fontWeight: "bold", marginRight: "3px" }}>
                                        {module.tableCount}
                                    </span>
                                    Tables
                                </span>
                            </div>

                            {activeTab !== "nvalued" && module.isExpanded && (
                                <div className="dbm-search-box-wrapper">
                                    <input
                                        type="text"
                                        placeholder="Enter a keyword to search"
                                        className="dbm-search-input"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    <span className="dbm-search-icon">
                                        <IoIosSearch />
                                    </span>
                                </div>
                            )}

                            {activeTab !== "nvalued" && module.isExpanded && (
                                <div className="tables-list">
                                    {module.tables.length > 0 ? (
                                        module.tables.map((table) => (
                                            <div
                                                key={table}
                                                className={`table-item ${selectedTable === table ? "active" : ""}`}
                                                onClick={() => {
                                                    setSelectedTable(table);
                                                    setSelectedColumn(null);
                                                }}
                                            >
                                                <span className="table-name">{table}</span>
                                            </div>
                                        ))
                                    ) : (
                                        <div className="no-results">No tables found</div>
                                    )}
                                </div>
                            )}
                        </div>

                    </div>
                ))}
            </div>
        </div>
    );
};

export default LeftSidebar;
