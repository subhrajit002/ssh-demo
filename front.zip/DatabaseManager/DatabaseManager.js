import DatabaseManagerHeader from './headers/DatabaseManagerHeader';
import './DatabaseManager.css';
import DBMTabButtons from './DBMTabButtons/DBMTabButtons';
import { useEffect, useMemo, useState } from 'react';
import LeftSidebar from './LeftSidebar/LeftSidebar';
import RightPanel from './RightPanel/RightPanel';
import axios from 'axios';

const DatabaseManager = () => {
  const [activeTab, setActiveTab] = useState("columns");
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddTableForm, setShowAddTableForm] = useState(false);
  const [selectedModule, setSelectedModule] = useState("");
  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedColumn, setSelectedColumn] = useState(null);
  const [successMessage, setSuccessMessage] = useState("");
  const [selectedSchemaKey, setSelectedSchemaKey] = useState("");
  const [selectedModuleName, setSelectedModuleName] = useState("");
  const [modules, setModules] = useState([]);
  const [loadingTables, setLoadingTables] = useState(false);
  const [tablesError, setTablesError] = useState("");


  const SCHEMA_TO_MODULE = {
    scldp: "Demand Planning",
    sclrp: "Replenishment Planning",
    scldi: "Data Integrator",
    scltf: "Tradeflow",
    sclbl: "Business Layer",
  };

  const buildModulesFromApi = (apiData) => {
    const schemasObj = apiData?.schemas || {};
    const built = [];

    Object.entries(schemasObj).forEach(([schemaKey, schemaData]) => {
      const moduleName = SCHEMA_TO_MODULE[schemaKey] || schemaKey.toUpperCase();
      const tables = Array.isArray(schemaData?.tables) ? schemaData.tables : [];
      const tableCount =
        typeof schemaData?.tableCount === "number" ? schemaData.tableCount : tables.length;

      built.push({
        name: moduleName,
        schemaKey: schemaKey,
        tableCount,
        isExpanded: false,
        tables: tables.slice().sort((a, b) => a.localeCompare(b)),
      });
    });

    return built;
  };


  const getAllTables = async () => {
    const url = "http://localhost:8080/database-manager/tables";
    setLoadingTables(true);
    setTablesError("");

    try {
      const res = await axios.get(url, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      const builtModules = buildModulesFromApi(res.data);
      setModules(builtModules);

      if (builtModules.length > 0) {
        setSelectedModuleName(builtModules[0].name);
        setSelectedSchemaKey(builtModules[0].schemaKey);
      }

    } catch (err) {
      console.error(err);
      setTablesError(
        err?.response?.data?.message ||
        err?.message ||
        "Failed to load tables."
      );
      setModules([]);
    } finally {
      setLoadingTables(false);
    }
  };

  useEffect(() => {
    getAllTables();
  }, [])


  const filteredModules = useMemo(() => {
    return modules.map((module) => ({
      ...module,
      tables: (module.tables || []).filter((table) =>
        table.toLowerCase().includes(searchTerm.toLowerCase())
      ),
    }));
  }, [modules, searchTerm]);

  const toggleModule = (index) => {
    setModules(prev =>
      prev.map((m, i) => {
        if (activeTab === "nvalued") {
          return { ...m, isExpanded: i === index ? !m.isExpanded : false };
        }

        // 👉 Other tabs → normal toggle
        if (i === index) {
          return { ...m, isExpanded: !m.isExpanded };
        }

        return m;
      })
    );
  };


  useEffect(() => {
    setSelectedTable(null);
    setSelectedColumn(null);
    setSelectedModule("");
    setSuccessMessage("");
    setShowAddTableForm(false);

    // 🔥 collapse all modules in left sidebar
    setModules(prev =>
      prev.map(m => ({ ...m, isExpanded: false }))
    );
  }, [activeTab]);


  return (
    <div className="database-Manager">
      {/* <DatabaseManagerHeader /> */}
      <div className="dbm-body">
        <div className="table-management-container">
          <DBMTabButtons setActiveTab={setActiveTab} activeTab={activeTab} />

          <div className="main-container">
            {loadingTables ? (
              <div className="no-results">Loading tables...</div>
            ) : (
              <>
                <LeftSidebar
                  filteredModules={filteredModules}
                  toggleModule={toggleModule}
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  selectedTable={selectedTable}
                  setSelectedTable={setSelectedTable}
                  setSelectedColumn={setSelectedColumn}
                  selectedModule={selectedModule}
                  setSelectedModule={setSelectedModule}
                  loadingTables={loadingTables}
                  tablesError={tablesError}
                  setSelectedSchemaKey={setSelectedSchemaKey}
                  activeTab={activeTab}
                />

                <RightPanel
                  activeTab={activeTab}
                  selectedModule={selectedModule}
                  modules={modules}
                  selectedSchemaKey={selectedSchemaKey}
                  selectedTable={selectedTable}
                  toggleModule={toggleModule}
                />
              </>
            )}

          </div>
        </div>
      </div>
    </div >
  );
};

export default DatabaseManager;