import React from 'react'
import './DatabaseManagerHeader.css'

const DatabaseManagerHeader = () => {
    return (
        <div className="databaseManager-header">
            <p>Database Manager</p>
        </div>
    )
}

export default DatabaseManagerHeader